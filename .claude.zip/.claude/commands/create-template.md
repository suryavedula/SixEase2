---
name: create-template
description: Add a new storefront template from a prototype, end-to-end — includes every integration point (onboarding, admin, visual editor, storefront, backend) that's silently breakable if missed.
parameters:
  - name: templateId
    description: Kebab-case template ID (e.g., `gelados-premium`, `padaria-artesanal`). Used as folder name, config key, and URL param.
    required: true
  - name: prototypePath
    description: Path to the prototype directory (e.g., `prototype/gelado1-main(1)/`). Skip if starting from scratch.
    required: false
  - name: industry
    description: TemplateIndustry value (e.g., `FOOD`, `FASHION`, `RESTAURANT`). If new, adds it to the union and all mappings.
    required: true
  - name: siteMode
    description: Backend SiteMode the template targets (`LOJA`, `MENU`, `LANDING_CORPORATE`, `LANDING_PERSONAL`, `EDUCACAO`, `SERVICOS`). Affects onboarding step order + `inferSiteMode` routing.
    required: true
---

# Create Storefront Template From Prototype

End-to-end guide for adding a template to KitandaSmart. **The point of this skill is the list of integration points that are silently breakable** — config + components alone are ~60% of the work. The other 40% is onboarding, admin, and visual-editor wiring.

## Why this skill exists

Prior templates (ZAM, HOXI, Nexus, **Hyper Retail**) shipped with gaps:

- **HOXI** landed without a `KNOWN_TEMPLATES` backend entry → admin dashboard filters it out; onboarding catalog endpoint hides it.
- **HOXI** wholesale sections read slot keys (`page.grosso.hero.title`) that didn't match the declared config slots (`page.grosso.title`) → CMS edits silently ignored at render time.
- **FOOD industry** wasn't added to `admin/templates/page.tsx` `INDUSTRY_TABS` → no filter tab for it.
- **Hyper Retail** (TASK-227-NEXT, May 2026) shipped with five compounding gaps that all read as "the template is broken" to a vendor:
  1. Header had a `search` input that was pure decoration — no `<form>`, no submit, no route. Vendor types and presses Enter, nothing happens. **The fix is to reuse `sections/common/SearchBar.tsx` whose handler already pushes `${getPathPrefix()}?search=X`.** Never roll your own.
  2. "Ver Todos os Produtos" / "Ver Todas Ofertas" buttons linked to `/products` — but **there is no `/products` listing route** in `app/(storefront)/[store]/`, only `/products/[slug]/`. Every such link 404s. Same for `/products?category=X` — the homepage `?category=X` filter works because `[store]/page.tsx` reads it, but a bare `/products?...` URL has no page to render.
  3. `FlashSaleHyper` and `OffersGridHyper` both filtered `compareAtPrice > price` from the same product list with near-identical card layout. The two sections read as duplicates, not as "limited-time urgency" + "permanent clearance." **Two sections that look the same on a single homepage feel like the template is broken or padded.**
  4. The `TestimonialsHyper` component reads `data.testimonials` but the template config did not set `features.testimonials: true`. `resolveIncludes()` (`frontend/lib/templates/helpers/resolve-includes.ts`) only adds `"testimonials"` to the SSR fetch list when that flag is on. Result: the array arrives empty and the component falls back to hardcoded fixtures forever. The vendor adds testimonials in admin, sees nothing on the storefront, assumes the feature is broken. **Same trap exists for `portfolio`, `teamManagement`, `socialLinks`, `partners`, `blog`, `gallery`, `courses`, `services`, `locations`** — each is gated by an explicit feature flag (see Phase 5.5 below).
  5. Header navigation included anchors like `#categorias` which only resolve on the homepage. From `/products/[slug]`, `/cart`, etc. the anchor goes to `#categorias` of the *current* page (no such id) and silently does nothing. **Anchors must be authored as `${homeHref}#anchor`** (HeaderGelato precedent at `headers/HeaderGelato.tsx:41-50`) so they navigate home first.

Every section below lists a concrete **"touch this file"** instruction. Skip nothing.

---

## Phase 0 — Inventory the prototype (if provided)

Before writing code, extract these from the prototype so you know the full scope:

1. **Sections** — list every structurally-distinct section (hero, product row, about, contact, footer…). Each becomes one component + one registry entry + one sectionGroupMap entry.
2. **Pages** — homepage is implicit; any other route (`/grosso`, `/sobre`, `/servicos`) becomes a `PageConfig` + entries in `PAGE_SECTION_REGISTRY`.
3. **Color tokens** — count unique colors. Map each to the 17-token `ColorScheme` shape (`primary`, `secondary`, `accent`, `background`, `foreground`, `muted`, `mutedForeground`, `card`, `cardForeground`, `border`, `destructive`/-`Foreground`, `success`/-`Foreground`, and the 3 `*Foreground` twins). Extras → derive with `color-mix()` at the call site; don't extend the schema.
4. **Fonts** — count unique families. Each new family needs a `next/font` entry in `app/layout.tsx` + a `fontFamily` key in `tailwind.config.ts`.
5. **Third-party integrations** — maps, analytics, payment widgets. Each needs an env var in 4 places (see Phase 7).
6. **Editable content** — every string, image, URL a vendor would want to change. These become `contentSlots`. Store settings (phone/email/hours/address/social URLs/logo/color scheme/font) are **never** slots — use `settingsForm: "contact"` or the existing settings pipeline.

### 0a. Section uniqueness audit (Hyper-Retail lesson)

For every pair of sections in `sections.industry[]`, answer in one sentence each: **what data does each pull from?** and **what is the visual treatment?** If two sections answer both questions the same way, you have a duplicate. Either drop one, or differentiate them *before* writing code.

Concrete differentiation patterns when two sections look related:
- **Time-bound vs evergreen** — one section reads `endsAt`/countdown, the other doesn't. Different copy, different urgency UI.
- **Featured vs all** — one renders `data.featuredProducts.filter(p => p.featured)`, the other reads `data.products.content` filtered by a different criterion (e.g. `compareAtPrice` discount, `categorySlug` match).
- **Different layouts** — grid-of-4 vs scrollable carousel vs single hero card. If both are `grid grid-cols-2 md:grid-cols-4`, vendors will read them as duplicates.
- **Different anchor IDs** — required for nav, but also a smell test: if you can't think of two distinct anchor names, the sections are probably the same.

If the prototype HTML has two sections that differ only in title text, **trim to one**. Three "products in a grid" rows on a homepage looks padded, not rich.

### 0b. Search wiring decision (Hyper-Retail lesson)

If the prototype header (or any section) has a search input, decide before writing the component:

- **Reuse `frontend/components/storefront/sections/common/SearchBar.tsx`** — its handler already pushes to `${getPathPrefix()}?search=X` which the homepage's `[store]/page.tsx` reads. Inline its logic into your custom header, or render `<SearchBar />` from the registry.
- **OR omit the search input entirely.** A decorative search field that does nothing is worse than no search field — vendors and customers both read it as broken.

Never write your own `useState` + uncontrolled `<input>` for search. There is exactly one search route in this project; there is exactly one way to navigate to it.

### 0c. Data-dependency audit (Hyper-Retail lesson)

For every `SectionData` field your components plan to consume (`data.testimonials`, `data.portfolioItems`, `data.teamMembers`, `data.partners`, `data.locations`, `data.blogPosts`, `data.galleryItems`, `data.courses`, `data.services`, `data.socialLinks`, `data.menuItems`), verify the corresponding `features.X` flag will be set in your template config (see Phase 5.5 — feature-flag wiring). The SSR `resolveIncludes()` helper builds the fetch list from these flags; without them you get `[]` and your section silently degrades to fallbacks.

Default-populated fields that need NO flag: `data.store`, `data.categories`, `data.featuredProducts`, `data.products`, `data.currentCategory`, `data.currentSearch`, `data.isPlaceholder`, `data.isPreviewMode`. Everything else is gated.

### 0d. Route coverage audit (Hyper-Retail lesson, see also Phase 11)

Before designing CTA copy ("Ver Todos os Produtos", "Ver Coleção Completa", "Comprar todas as ofertas"), check what storefront routes actually exist in `app/(storefront)/[store]/`. There is **no `/products` listing page** in this project — only `/products/[slug]`. Linking your CTAs to `/products` makes them 404. Plan now to either:
- Point "Ver Todos" at the homepage with a section anchor (`${homeHref}#produtos`).
- Use the `?category=X` / `?search=X` filters on the homepage (which `[store]/page.tsx` *does* read).
- Build a custom `/products/page.tsx` route wrapped by your template's chrome (significant scope; only worth it for premium templates).

Read `frontend/lib/templates/COOKBOOK.md` and `PROTOTYPE_GUIDE.md` if the prototype pattern is unfamiliar.

---

## Phase 1 — Template config & industry wiring (frontend/lib/templates/)

### 1a. TemplateIndustry union — only if industry is new

`frontend/lib/templates/types.ts` — add industry string to the `TemplateIndustry` union (ends at line ~23). If industry already exists, skip this block entirely.

### 1b. ColorScheme union — only if color scheme is new

Three places keep the `ColorScheme` list in sync — **all three must match** or onboarding breaks:

- `frontend/types/index.ts:45-65` — frontend TS union
- `frontend/types/storefront.ts:21-25` — duplicate frontend TS union (drifts if only one is edited)
- **`backend/src/main/java/ao/kitandasmart/entity/enums/ColorScheme.java`** — Jackson-backed Java enum. If missing the new value, `POST /api/v1/onboarding/complete` returns HTTP 500 with `InvalidFormatException: Cannot deserialize value of type ColorScheme from String "MY_SCHEME": not one of the values accepted for Enum class: [...]`. This is the exact failure mode HOXI hit — frontend picker accepts the scheme, onboarding submit explodes.

Add the new ID to all three. Enum insert order matters only for Jackson error messages — put it alphabetically near related values (GELATO_PINK landed before CUSTOM, next to BRASA_DARK/ZAM_DARK).

Same pattern applies to **`backend/.../entity/enums/FontFamily.java`** if your template introduces a new font family selectable via the user picker (not just a Tailwind utility like `font-display` — that's frontend-only and no backend sync needed).

**⚠️ Renaming an existing enum value requires a DB migration.** The Java enum is persisted as a string in `stores.color_scheme` (and similar columns for other enums). Renaming `X` → `Y` in the Java file without `UPDATE stores SET color_scheme = 'Y' WHERE color_scheme = 'X'` causes `IllegalArgumentException: No enum constant ...X` on the next store load. If any existing rows carry the old value, either (a) add the new value + keep the old (soft-deprecate), or (b) UPDATE the rows, then remove the old value in a second pass. Also `FLUSHDB` the Redis cache after a backend restart during dev — serialized DTOs from the previous JVM classloader become uncastable.

### 1c. Color scheme preset

`frontend/lib/data/color-schemes.ts` — add the new preset into the `COLOR_SCHEMES` record with all 17 color tokens + a 3-swatch `preview` block. Reference: GELATO_PINK (line 521), BRASA_DARK, ZAM_DARK.

### 1d. Template config file

Create `frontend/lib/templates/configs/{industry}/{templateId}.ts`. Must export a `TemplateConfig` with:
- `id`, `name`, `industry`, `style`, `description`, `defaultColorScheme`
- `sections`: `header`, `hero`, `industry[]`, `footer`, optional `whatsapp` / `categories` / `featuredProducts` / `products` / `announcement`
- `navigation: { mobile: { type: ... }, desktop: "top-nav" | "side-nav" }`
- `defaultStyles: { spacing, corners, shadows, cardStyle }`
- Optional: `pages`, `navAnchors`, `contentGroups`, `contentSlots`, `sectionGroupMap`, `features`

Reference gold-standard: `frontend/lib/templates/configs/corporate/zam-events.ts` (multi-page, full CMS); `frontend/lib/templates/configs/food/gelados-premium.ts` (pages + products + CMS).

### 1e. Register config + mapping updates

`frontend/lib/templates/configs/index.ts`:
- Add `import { myTemplate } from "./{industry}/{templateId}";`
- Add `"{templateId}": myTemplate,` to `ALL_CONFIGS`.
- **If industry is new**, edit 4 maps:
  - `INDUSTRY_TO_STORE_TYPE` (~line 115): `NEW_INDUSTRY: "NEW_STORETYPE"`
  - `STORE_TYPE_TO_INDUSTRY` (~line 138): ensure the StoreType points to the right industry (flip any stale `X: "RESTAURANT"` fallback).
  - `LOJA_INDUSTRIES` / `MENU_INDUSTRIES` / etc. (~line 167): add the industry to the appropriate SiteMode bucket via `INDUSTRIES_BY_SITE_MODE`.
  - `INDUSTRY_LABELS` (~line 178): add `NEW_INDUSTRY: "Rótulo em português"`.

### 1f. Section types in the discriminated union

`frontend/lib/templates/types.ts`:
- New header/hero/footer variants → add `Header{Name}Config` / `Hero{Name}Config` / `Footer{Name}Config` interfaces + add them to the `HeaderConfig` / `HeroConfig` / `FooterConfig` unions.
- New industry sections → add `{SectionName}Config` interfaces + extend the `IndustrySectionConfig` union (~line 690-780).

---

## Phase 2 — Section components (frontend/components/storefront/sections/)

One component per section. File layout:
- Headers: `headers/Header{Name}.tsx`
- Heroes: `heroes/Hero{Name}.tsx`
- Footers: `footers/Footer{Name}.tsx`
- Industry sections: `industry/{industry}/{SectionName}.tsx`
- Page sections: same folder as industry (HOXI precedent) — registered in `PAGE_SECTION_REGISTRY` not `INDUSTRY_REGISTRY`.

Every component must:

1. Start with `"use client";`.
2. Accept `SectionProps<TConfig>` (homepage) or `PageSectionProps` (sub-pages). Never both.
3. Read editable content via `resolveContent(store, key, fallback)` from `@/lib/templates/helpers/site-content`.
4. Use CSS variables for colors: `var(--color-primary)`, `var(--color-accent)`, etc. Derive missing shades with `color-mix(in srgb, var(--color-X) 85%, black)`. No hardcoded hex except documented identity-color overrides (e.g., HOXI footer's `#1a1a1a`).
5. Use `useCart()` from `@/components/storefront/providers` for add-to-cart; never create per-template cart state.
6. Use `useStorefrontNav().getHref()` / `getHomeHref()` / `getPageHref(slug)` for all links so preview mode works correctly. **Anchors must be authored as `${getHomeHref()}#anchor`, never bare `#anchor`** — bare anchors only resolve on the homepage and silently no-op from `/products/[slug]`, `/cart`, etc. (HeaderGelato precedent at `headers/HeaderGelato.tsx:41-50`.)
7. Use `formatPrice(product.price)` from `@/lib/templates/helpers` — never hardcode `"Kz"`.
8. Use `getWhatsAppUrl(phone, message)` from `@/lib/api/storefront` for any WhatsApp handoff. Follow the fallback `store.contact?.whatsappNumber || store.contact?.phone`.
9. For sub-pages, read typed customization off `config.props` (not a typed generic — page sections use `PageSectionConfig` which exposes `props: Record<string, unknown>`).
10. Portuguese copy everywhere (see `CLAUDE.md`).
11. **Search inputs**: reuse `frontend/components/storefront/sections/common/SearchBar.tsx` rather than re-implementing. Its handler pushes to `${getPathPrefix()}?search=X` which is the only search route in this project. Decorative search inputs without a submit handler are a forbidden anti-pattern (see Phase 0b).
12. **CTA hrefs to non-existent routes**: never link to `/products` (no top-level listing route exists), `/products?category=X` as a bare URL (no rendering page), `/search` (no such route). All "see all" CTAs go to `${getHomeHref()}#section-anchor` or to a real `/products/[slug]` URL. (See Phase 11 for the full route inventory.)

### Registries

`frontend/lib/templates/registry.ts`:
- `HEADER_REGISTRY`, `HERO_REGISTRY`, `FOOTER_REGISTRY` — add one-line `dynamic()` import per new variant.
- `INDUSTRY_REGISTRY` — add one per new homepage industry section type. Use a group-header comment (`// Food (HOXI)`) for discoverability.

`frontend/lib/templates/page-registry.ts`:
- `PAGE_SECTION_REGISTRY` — add one per new sub-page section type. **Do not use INDUSTRY_REGISTRY for page sections** — page renderer resolves via PAGE_SECTION_REGISTRY only.

### Sub-page route folders — **CRITICAL, hits Next.js routing not your template**

The `frontend/app/(storefront)/[store]/` tree uses **static folders, not a catch-all**. Every sub-page slug declared in `config.pages` must have a matching folder with `page.tsx` + `{Name}PageClient.tsx` under `[store]/` — otherwise Next.js returns 404 before the template renderer runs. Declaring `pages.grosso` in the template config alone is **not** enough.

Existing slugs with route folders: `quem-somos`, `servicos`, `contactos`, `contactar`, `sobre-nos`, `galeria`, `parcerias`, `portfolio`, `blog`, `formacoes`, `cursos`, `certificado`.

**Template:**

```tsx
// app/(storefront)/[store]/{slug}/page.tsx
import type { Metadata } from "next";
import { getCachedStore } from "@/lib/api/storefront-cached";
import { buildStoreMetadata } from "@/lib/seo";
import { resolvePageConfig } from "@/lib/templates/helpers/resolve-template";
import {Name}PageClient from "./{Name}PageClient";

export const revalidate = 3600;

interface PageProps { params: Promise<{ store: string }>; }

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { store: storeSlug } = await params;
  try {
    const store = await getCachedStore(storeSlug);
    const resolved = resolvePageConfig(store, "{slug}");
    const title = resolved?.pageConfig.title || "Fallback Title";
    return buildStoreMetadata({ store, title, path: "/{slug}" });
  } catch {
    return { title: "Fallback Title" };
  }
}

export default function {Name}Page() { return <{Name}PageClient />; }
```

```tsx
// app/(storefront)/[store]/{slug}/{Name}PageClient.tsx
"use client";
import { notFound } from "next/navigation";
import { useTheme } from "@/components/storefront/providers";
import { resolvePageConfig } from "@/lib/templates/helpers/resolve-template";
import PageRenderer from "@/components/storefront/PageRenderer";

export default function {Name}PageClient() {
  const { store } = useTheme();
  const resolved = resolvePageConfig(store, "{slug}");
  if (!resolved) notFound();
  return <PageRenderer pageConfig={resolved.pageConfig} templateConfig={resolved.templateConfig} store={store} />;
}
```

For slugs that also have a legacy (pre-template) rendering (e.g. `quem-somos`), the client falls back to a hardcoded layout when `resolvePageConfig` returns null — see `app/(storefront)/[store]/quem-somos/QuemSomosPageClient.tsx` for that pattern. For template-only slugs (HOXI's `/grosso`), `notFound()` is correct.

---

## Phase 3 — Global font & Tailwind (frontend/app/ + tailwind)

Only if the template needs a new Google Font.

`frontend/app/layout.tsx`:
- Import from `next/font/google`: `const myFont = MyFont({ subsets: ["latin"], weight: "400", variable: "--font-my", display: "swap" });`
- Add `${myFont.variable}` to the `<html>` className alongside `inter.variable`.

`frontend/tailwind.config.ts`:
- Under `theme.extend.fontFamily`: `display: ["var(--font-my)", "cursive"]` (or another utility name).

Components can then use `className="font-display"`.

---

## Phase 4 — Mock data for preview (frontend/lib/templates/mock-data.ts)

The preview route renders without a real backend. Every template that uses custom products or specific portfolio/testimonials needs mocks wired through per-template getters.

1. **Products** — add `MOCK_PRODUCTS_{NAME}` + `MOCK_PAGINATED_PRODUCTS_{NAME}`. Then extend:
   - `getMockProductsForTemplate(templateId)` — returns the paginated wrapper.
   - `getMockFeaturedProductsForTemplate(templateId)` — returns the `featured: true` subset.
2. **Portfolio / testimonials** — if the template uses them, add to `getMockPortfolioForTemplate()` / `getMockTestimonialsForTemplate()` dispatchers.
3. **Industry defaults** — add entries to `INDUSTRY_NAMES` and `INDUSTRY_DESCRIPTIONS` in `createMockStoreForIndustry()` if the industry is new.

The preview page (`frontend/app/preview/page.tsx`) already reads through these dispatchers; you do not edit the preview route.

Use Unsplash-seeded or `picsum.photos/seed/...` images for deterministic mock images. Set `referrerPolicy="no-referrer"` on `<img>` to avoid 403s.

---

## Phase 5 — Backend integration (backend/src/main/java/ao/kitandasmart/)

### 5a. KNOWN_TEMPLATES map — **CRITICAL, almost always forgotten**

`backend/src/main/java/ao/kitandasmart/service/AdminTemplateService.java:34-82` maintains a **hardcoded** `KNOWN_TEMPLATES` static `LinkedHashMap<String, TemplateMeta>`.

Add an entry for the new template:

```java
KNOWN_TEMPLATES.put("{templateId}", new TemplateMeta("{Display Name}", "{INDUSTRY}", "{style}", "{Portuguese description}"));
```

Two endpoints filter through this map (`getAllTemplates` line 130, `getPublicCatalog`):
- `/api/v1/admin/templates` — admin dashboard list (see 6a).
- `/api/v1/templates/catalog` — onboarding's curated catalog toolbar.

**If you skip this step the template is invisible to both admin and onboarding catalog.** Frontend `ALL_CONFIGS` alone is not enough.

Use a grouping comment (`// Food`) to match the file's existing industry grouping.

### 5b. StoreType enum — only if new industry means new store type

`backend/src/main/java/ao/kitandasmart/entity/enums/StoreType.java` — enum value list. `FOOD` / `FASHION` / `RESTAURANT` / `HEALTH` / `EDUCATION` / `CORPORATE` / `PERSONAL` / `SERVICES` / `PHARMACY` / `HARDWARE` and legacy types (`ELECTRONICS`, `HOME`, `SPORTS`, etc.) already exist. If your industry maps to any of these, no change. If truly new, add the enum value — then write a Liquibase changeset in `backend/src/main/resources/db/changelog/` because this enum persists in `stores.store_type`.

### 5c. inferSiteMode routing

`backend/src/main/java/ao/kitandasmart/service/OnboardingService.java:126-137`:

- LOJA templates: ensure the StoreType falls through to `default -> SiteMode.LOJA`. Split it off any grouped case if currently grouped with another mode (HOXI precedent: `FOOD` split from `case RESTAURANT, FOOD -> MENU`).
- MENU / EDUCACAO / LANDING_CORPORATE / LANDING_PERSONAL / SERVICOS: add an explicit `case X -> SiteMode.Y` entry.

Gate on a **pre-flight DB check**: `SELECT COUNT(*) FROM stores WHERE store_type = '<TYPE>';`. If > 0, those stores already have a `site_mode` row — coordinate a Liquibase migration before flipping the routing or you'll change live-store behavior.

### 5d. `features` flags → `resolveIncludes()` SSR fetch list — **silent-empty-array trap**

The storefront homepage SSR (`frontend/app/(storefront)/[store]/page.tsx`) calls `getStorefrontContext(slug, includes)` to fetch optional entity data. The `includes` array is built by `frontend/lib/templates/helpers/resolve-includes.ts` from your template config's `features` block. The mapping (`FEATURE_TO_INCLUDE`):

| `features.X` flag in config | SSR include | `data.X` field a component reads |
|---|---|---|
| `portfolio: true` | `"portfolio"` | `data.portfolioItems` |
| `teamManagement: true` | `"team"` | `data.teamMembers` |
| `testimonials: true` | `"testimonials"` | `data.testimonials` |
| `socialLinks: true` | `"socialLinks"` | `data.socialLinks` |
| `partners: true` | `"partners"` | `data.partners` |
| `blog: true` | `"blog"` | `data.blogPosts` |
| `gallery: true` | `"gallery"` | `data.galleryItems` |
| `courses: true` | `"courses"` | `data.courses` |
| `services: true` | `"services"` | `data.services` |
| `locations: true` | `"locations"` | `data.locations` |

**If a component reads `data.X` but the corresponding `features.Y` flag is missing, the SSR returns an empty array and the component silently falls back to whatever default it ships with (often hardcoded fixtures).** The vendor adds the data in admin, sees nothing on the storefront, files a "feature is broken" bug.

Verification:
- For every `data.X` reference in your component grep, look up the row above and confirm the matching `features.Y: true` is in your config.
- For `features.testimonials` specifically, confirm the public endpoint `/api/v1/storefront/{slug}/testimonials` exists (it does, served by `TestimonialController`) and the admin can write to `/api/v1/stores/my/testimonials` (it does — but vendors must know where it is in the dashboard).
- Some site modes auto-include irrespective of features (see `resolve-includes.ts:19-31`): `MENU` → `["menu"]`, `LANDING_PERSONAL` / `SERVICOS` → `["portfolio", "socialLinks"]`. LOJA mode adds **nothing** automatically — every optional include must be a `features.*` flag.

There is also a per-template content side-effect: `hasCourses` is auto-detected from `sections.industry[].type` containing `course` (line 52). Don't rely on it for non-course sections; set `features.courses: true` explicitly when in doubt.

---

## Phase 6 — Admin panel wiring (frontend/app/(admin)/admin/)

### 6a. Industry filter tabs — hardcoded list

`frontend/app/(admin)/admin/templates/page.tsx:16-27` — `INDUSTRY_TABS` array is hardcoded and **does not** read from `INDUSTRY_LABELS`. If your industry is new, add:

```tsx
{ key: "FOOD", label: "Alimentação" },
```

Without this, admins can't filter by the new industry (templates still show under "Todos" — but discoverability suffers).

### 6b. Admin detects templates via KNOWN_TEMPLATES (already covered 5a)

No other admin wiring is needed once `KNOWN_TEMPLATES` lists the template. Feature toggles / enable-disable / featured-flag are edited from the admin UI and stored in the `template_settings` table.

---

## Phase 7 — Visual editor / Dashboard CMS (frontend/app/(dashboard)/content/)

The CMS is data-driven: `contentGroups` + `contentSlots` + `sectionGroupMap` in the template config are rendered automatically by `BlueprintCmsForm`. That said, there are still two fixed integration points:

### 7a. ICON_MAP extension

`frontend/app/(dashboard)/content/page.tsx:57-73` — `ICON_MAP` whitelists lucide icon names usable by `contentGroups[].icon`. Currently registered: `layout`, `info`, `image`, `briefcase`, `link`, `users`, `mail`, `graduation-cap`, `message-square-quote`, `file-text`, `ice-cream`, `map-pin`, `handshake`. If your config uses a new icon name, add it (import + map entry). Missing icons fall back to `Layout` (line 70) — renders fine but loses the intended visual cue.

### 7b. Slot-key parity — **silent-failure zone**

The deadliest bug in CMS wiring: a **mismatch between slot keys declared in `contentSlots` and slot keys read by components via `resolveContent()`**. The CMS form writes to the declared key; the component reads a different key; the render uses the hardcoded fallback. Vendors see no error — just edits that don't apply.

Verification checklist before close:
- For every slot in `contentSlots`, grep the components folder: `resolveContent(store, "<key>"`. Exactly one component must read it.
- For every `resolveContent(store, "..." ...)` call in the template's components, the key must appear in `contentSlots`.
- If the section uses a `slotPrefix`, every slot under that prefix either (a) is read by the component, or (b) is intentionally omitted (rare — document in a comment).
- Array prefixes (`slotPrefix: ["home.about.", "home.mvv."]`) are supported — pattern in `zam-events.ts`.
- `slotKeys: [...]` lists exact keys (e.g., when two sections share the same prefix but only one owns a specific key like `page.grosso.whatsappMessage`).

### 7c. Link-picker anchor registry

CTA slots with `type: "url"` render as a 3-tab picker (Secção / Outra página / Link externo) in `BlueprintCmsForm.tsx` via `LinkPickerField`. The **Secção** tab is auto-populated from three sources merged in order:

1. `sections.header.navItems[].anchor` (author-curated labels)
2. `config.navAnchors[]` (single-page templates)
3. `SECTION_ANCHORS` registry in `BlueprintCmsForm.tsx` — maps section `type` → `{ anchor, label }` automatically from the template's `sections.industry[]` list.

**When adding a new industry section component with an in-page anchor:**
- Give the root element an `id="..."` attribute (rendered on the live page for `#anchor` navigation).
- Add a one-line entry to `SECTION_ANCHORS` mapping the section `type` string → `{ anchor, label }` (Portuguese label). Every template using that section type inherits the Secção option automatically — no per-template work required.

If a template uses only sections without anchor IDs, the Secção tab is disabled with a Portuguese fallback message; vendors still have "Outra página" (all `config.pages` + homepage) and "Link externo" (freeform URL) tabs.

### 7d. settingsForm vs custom slots

- `settingsForm: "contact"` — section maps to the store-wide contact form (phone/email/address/hours/socials/logo). Never duplicate these as slots.
- `entityPage: "/products"` / `"/products?featured=true"` — section is driven by real entities, not text slots. Used for product-grid sections where vendors manage items in the dashboard, not as inline text.
- Custom `slotPrefix` — section's editable copy comes from the `contentSlots` declared in the config.

A section can use `slotPrefix` AND `settingsForm` (header/footer do this — nav text is slot-driven, phone/email come from settings).

### 7d. Color-scheme picker & font picker

Both are data-driven:
- `ColorSchemeSelector` in onboarding and dashboard reads `COLOR_SCHEMES` automatically — new scheme appears without changes.
- Font picker (if present) reads `FontFamily` enum in `types/index.ts` — extend only if introducing a font selectable project-wide (not just by one template).

---

## Phase 8 — Environment variables (infrastructure)

Only if the template needs a third-party integration (Google Maps embed, Stripe widget, analytics script).

For `NEXT_PUBLIC_*` vars (exposed to the browser):
1. `.env.example` — document with inline comment explaining fallback behavior.
2. `frontend/Dockerfile` — add `ARG NEXT_PUBLIC_{VAR_NAME}` before `RUN npm run build`.
3. `docker-compose.yml` — frontend service `environment:` block: `NEXT_PUBLIC_{VAR_NAME}: ${NEXT_PUBLIC_{VAR_NAME}:-}`.
4. `docker-compose.prod.yml` — same, under both `build.args:` and `environment:`.

**Graceful degradation is required.** If the var is empty in production, components must fall back to a usable state (deep-link only, static placeholder, etc.). Precedent: `GelatoStoreLocator.tsx:101-121` renders a static card with a "Como chegar" deep-link when `NEXT_PUBLIC_GOOGLE_MAPS_EMBED_KEY` is unset.

For backend env vars, follow the existing Spring `application.yml` + `env:` pattern — out of scope for most templates.

---

## Phase 9 — Preview & smoke test

Required before the template is ready for review:

1. **Local preview routes** — hit all of:
   - `/preview?templateId={templateId}` (homepage)
   - `/preview?templateId={templateId}&page={slug}` (for every page in `config.pages`)
   - No console errors, no missing-registry warnings.

2. **Regression check on neighbors** — the HOXI work specifically flagged these as canaries for registry / mock-data regressions:
   - `/preview?templateId=zam-events`
   - `/preview?templateId=brasa-restaurant`
   - `/preview?templateId=nexus-corporate`
   - `/preview?templateId=consultex-corporate`
   - `/preview?templateId=fashion-premium` (products pagination path)

3. **Typecheck**: `docker-compose exec -T frontend npm run type-check` — HOXI changes added **zero** new errors. If your diff introduces any, fix before moving on (pre-existing unrelated errors in project are not your problem).

4. **Lint**: `docker-compose exec -T frontend npm run lint`.

5. **Backend compile** (if you touched Java): `docker-compose exec -T backend ./mvnw compile`.

6. **Dashboard CMS smoke**:
   - `/content` — 5 group cards render with correct icons (none fall back to generic `Layout`).
   - Click each group → form shows the expected slot labels/fields.
   - Edit one slot per group, save, refresh preview — change shows. **This is the slot-key parity test.**
   - For `settingsForm: "contact"` sections, form opens the contact form, not a slot editor.

7. **Onboarding flow**:
   - Create a fresh onboarding session → pick the industry → template appears in the list + in the "catalog" toolbar tab (confirms `KNOWN_TEMPLATES` is wired).
   - Select → preview works → complete → rendered storefront matches.

8. **Admin dashboard**:
   - `/admin/templates` → template appears under its industry tab (confirms INDUSTRY_TABS has the tab AND `KNOWN_TEMPLATES` has the entry).
   - Edit → toggle featured / enabled → storefront/onboarding responds.

9. **Mobile 360px** — visual check for every section. Target device-width class at DevTools 360 × 800.

---

## Phase 10 — Documentation

Update `frontend/lib/templates/COOKBOOK.md` **only** if you introduced a new pattern (first multi-page template, first template with third-party integration, first template using array `slotPrefix`, etc.). Do not copy-paste template-specific docs into the cookbook — link to the template config file as the reference.

If the template comes from a prototype, leave a one-line note in the config file's top comment pointing at the prototype path, so future maintainers can cross-reference.

---

## Phase 11 — Route coverage for LOJA / commerce templates (Hyper-Retail lesson)

The `TemplateRenderer` only wraps the **homepage** (`/[store]/page.tsx`) with your template's header/footer. Every other storefront route either uses a custom wrapper (which you must build) or falls back to the platform's default chrome — meaning your branded vendor lands on a Hyper Retail homepage, clicks "Comprar" on a product, and is taken to a generic-looking product detail page or, worse, a 404.

### 11a. Storefront route inventory (snapshot — verify with `ls app/(storefront)/[store]/` before linking)

| Route | Status | Default chrome? | Per-template override? |
|---|---|---|---|
| `/` | ✅ Renders via `TemplateRenderer` | n/a — your template chrome | n/a |
| `/products/[slug]` | ✅ Renders | Default `ProductDetailPage` | Yes — `templateId === "X"` ternary at `products/[slug]/page.tsx:66-68` (see Phase 10) |
| `/products` (listing) | ❌ **DOES NOT EXIST** | n/a | n/a — would 404 |
| `/products?category=X`, `/products?search=X` (bare) | ❌ **DOES NOT EXIST as a route** — the homepage reads these query params and filters | n/a | n/a |
| `/cart` | ✅ Renders | Default chrome | No precedent — would need a wrapper following the UniStoreProductDetailWrapper pattern |
| `/checkout` | ✅ Renders | Default chrome | Same as above |
| `/categories` | ✅ Renders (catalog browse) | Default chrome | Same |
| `/account`, `/login`, `/orders/[orderNumber]`, `/portal/*` | ✅ Render | Default chrome | Same |
| Slug routes from `config.pages` (e.g. `/grosso`, `/quem-somos`) | Render only if you create the static folder per Phase 2 | Wrapped via `PageRenderer` reading `PAGE_SECTION_REGISTRY` | n/a — your template's pages |

### 11b. CTA href rules

Every internal `href` (or `getHref(...)` argument) in your template's components must resolve to one of:
1. The homepage (`getHomeHref()`) — bare or with a known section anchor (`${getHomeHref()}#produtos`).
2. `/products/[slug]` for a real product slug (use real slugs from `data.products` / `data.featuredProducts`).
3. The homepage with a query filter the homepage actually reads: `?category=X` or `?search=X` (verify in `[store]/page.tsx:80-91` what params it parses).
4. A slug declared in `config.pages` (sub-page route folder + `PageRenderer` wired per Phase 2).
5. A real existing static folder under `[store]/` (e.g. `/cart`, `/checkout`, `/categories`, `/contactos`, `/quem-somos`, `/sobre-nos`, etc. — but **expect default chrome there**, see 11c).

Forbidden href patterns (will 404 or silently no-op):
- `/products` — no listing route exists.
- `/products?category=X` as a bare URL with no homepage-redirect intent.
- `/search` — no such route.
- Any `href` that's a bare anchor (`#produtos`) when the link can be clicked from a non-homepage route — anchor only resolves on the page it's authored on. Always prefix with `getHomeHref()` for cross-page anchors.

### 11c. When to build a per-template wrapper

For each non-homepage route where you want template chrome, mirror the `UniStoreProductDetailWrapper` / `HyperProductDetailWrapper` pattern:

1. Create `frontend/components/storefront/sections/<area>/<Template><Page>Wrapper.tsx` — a thin client component that imports the template's header/footer dynamically, fetches any extra data the page needs (e.g. categories list), wraps the inner page with `<StorefrontNavProvider templateId="<id>" ...>`, and renders the page content between header and footer.
2. Edit the route's `page.tsx` to add a `templateId === "<id>"` branch that renders your wrapper instead of the default page (precedent: `products/[slug]/page.tsx:66-70`).

**Build a wrapper when:** the route is on a primary commerce path (cart → checkout, product browsing) and the brand visually matters. **Skip the wrapper when:** the route is administrative (login, account, orders) and breaking out of the template chrome is acceptable.

### 11d. Empty-state UX

For LOJA stores with **zero categories** or **zero products** in the DB, your home sections should still render a usable layout. Test this before claiming the template is done:

```sql
-- in postgres container
DELETE FROM categories WHERE store_id = '<test-store-id>';
DELETE FROM products WHERE store_id = '<test-store-id>';
```

Then load the storefront. Each section should either:
- Hide itself when its data is empty (`if (items.length === 0) return null;`), OR
- Render a meaningful empty state (e.g. categories section: "Adicione categorias no painel admin para vê-las aqui").

A section that renders only its header + a single hardcoded promo card with no content reads as broken to the vendor.

---

## Master Checklist (paste into task file)

### Foundations
- [ ] 1b. `ColorScheme` — frontend `types/index.ts`, frontend `types/storefront.ts`, **AND backend `entity/enums/ColorScheme.java`** (Jackson will 500 onboarding otherwise)
- [ ] 1c. `COLOR_SCHEMES` preset (17 tokens + 3-swatch preview)
- [ ] 1a. `TemplateIndustry` union (if new)
- [ ] 1e. `INDUSTRY_TO_STORE_TYPE` / `STORE_TYPE_TO_INDUSTRY` / `INDUSTRIES_BY_SITE_MODE` / `INDUSTRY_LABELS`
- [ ] 1d. Template config file (`configs/{industry}/{id}.ts`)
- [ ] 1e. Config registered in `ALL_CONFIGS`
- [ ] 1f. Section config interfaces + added to discriminated unions
- [ ] 3. Global font loaded in `layout.tsx` + tailwind utility (if new)

### Components + registries
- [ ] Header / hero / footer components created + registered
- [ ] Industry section components created + registered in `INDUSTRY_REGISTRY`
- [ ] Page section components created + registered in `PAGE_SECTION_REGISTRY` (if multi-page)
- [ ] **Sub-page route folder created** at `app/(storefront)/[store]/{slug}/` with `page.tsx` + client (Next.js uses static folders, no catch-all — slug in config is NOT enough)
- [ ] All components use CSS vars, `useCart`, `useStorefrontNav`, `resolveContent`, `formatPrice`
- [ ] Portuguese copy everywhere
- [ ] **All anchors authored as `${getHomeHref()}#anchor`**, never bare `#anchor` (otherwise broken from any non-homepage route)
- [ ] **Search inputs reuse `sections/common/SearchBar.tsx` or are removed** (decorative inputs without submit handlers are forbidden — see Phase 0b)
- [ ] **Section uniqueness audit** done: no two sections pull from the same data with the same visual treatment (see Phase 0a)

### Mock data
- [ ] `MOCK_PRODUCTS_*` + dispatcher entries in `getMockProductsForTemplate` / `getMockFeaturedProductsForTemplate`
- [ ] Portfolio / testimonials mocks if used
- [ ] `INDUSTRY_NAMES` / `INDUSTRY_DESCRIPTIONS` in `createMockStoreForIndustry` (if new industry)

### Backend
- [ ] **`KNOWN_TEMPLATES` entry in `AdminTemplateService.java`** ← **most-forgotten step**
- [ ] `StoreType` enum value + Liquibase changeset (if truly new store type)
- [ ] `OnboardingService.inferSiteMode()` routes new StoreType correctly
- [ ] Pre-flight DB check for existing rows with the new store type recorded in task file

### Admin
- [ ] **`INDUSTRY_TABS` in `admin/templates/page.tsx`** (if industry is new)

### CMS / visual editor
- [ ] `contentGroups` declared in config
- [ ] `contentSlots` declared for every editable string/image/url
- [ ] `sectionGroupMap` wires every section → group (+ `slotPrefix` / `slotKeys` / `settingsForm` / `entityPage`)
- [ ] `ICON_MAP` extended for any new icon names used in `contentGroups[].icon`
- [ ] **Slot-key parity check** — every `resolveContent()` key appears in `contentSlots`, and vice versa
- [ ] `defaultValue` set for any slot a fresh store needs to render meaningfully

### Backend data flow (features → resolveIncludes)
- [ ] **For every `data.X` field your components read, the matching `features.Y: true` flag is set in the template config** (see Phase 5.5 table). Otherwise SSR returns `[]` and the section silently degrades to fallbacks.
- [ ] Verified vendors can add the entity in admin (testimonials, portfolio, team members, locations, etc.) — find or document the dashboard route.

### Route coverage (Phase 11)
- [ ] No `href` in any component points to a non-existent route. **Forbidden: `/products`, `/products?category=X` (bare), `/search`.**
- [ ] All "see all" CTAs go to `${getHomeHref()}#anchor` or to a real `/products/[slug]`.
- [ ] Empty-state UX for stores with 0 categories / 0 products tested manually (delete data in postgres, reload, every section either hides or shows a meaningful message).
- [ ] Decision recorded for whether to wrap `/cart`, `/checkout`, `/account`, `/login`, `/categories` with template chrome (per-template wrapper) or accept default chrome.

### Env vars (only if third-party integration)
- [ ] `.env.example` documented with fallback behavior
- [ ] `Dockerfile` ARG
- [ ] `docker-compose.yml` env
- [ ] `docker-compose.prod.yml` build args + env
- [ ] Graceful degradation when var is empty

### Smoke tests (before moving task to review)
- [ ] `/preview?templateId={id}` renders cleanly
- [ ] All sub-pages render
- [ ] 4 reference templates still render (ZAM, Brasa, Nexus, Consultex)
- [ ] `npm run type-check` (no new errors)
- [ ] `npm run lint`
- [ ] Backend `./mvnw compile` (if Java changes)
- [ ] Dashboard `/content` — 5 groups, icons correct, slot edit propagates to preview
- [ ] Onboarding flow shows template under industry filter
- [ ] Admin `/admin/templates` shows template under industry tab
- [ ] Mobile 360px visual spot-check

### Known anti-patterns to avoid
- Substituting "close-enough" existing components for prototype-specific ones. Build new; only reuse when 100% visually identical. (Reference: `memory/feedback_template_fidelity.md`.)
- Declaring slot keys the components don't read (or vice versa) — see 7b.
- Registering page sections in `INDUSTRY_REGISTRY` — they belong in `PAGE_SECTION_REGISTRY`.
- Hardcoding hex colors instead of CSS vars + `color-mix()`.
- Duplicating phone/email/hours as slots instead of `settingsForm: "contact"`.
- Creating per-template cart state — reuse `useCart()`.
- Skipping the `KNOWN_TEMPLATES` backend entry (template is invisible to admin + onboarding catalog).
- **Decorative search input with no submit handler** — vendors and customers both read it as broken. Reuse `sections/common/SearchBar.tsx` or omit the field. (Hyper Retail lesson, Phase 0b.)
- **Linking CTAs to non-existent routes** like `/products`, `/products?category=X` (bare), `/search` — they 404. Use `${getHomeHref()}#anchor` or filter the homepage with query params. (Phase 11.)
- **Two industry sections with the same data source + same visual treatment** — vendors read the homepage as duplicated/padded. Differentiate by data source, time-bound vs evergreen, or distinct layout. (Phase 0a.)
- **Reading `data.testimonials` / `data.portfolioItems` / `data.partners` / etc. without setting the matching `features.X: true` flag** — SSR returns `[]` and the section silently falls back to hardcoded fixtures forever. (Phase 5.5.)
- **Bare `#anchor` hrefs** — they only resolve on the homepage and silently no-op everywhere else. Always prefix with `${getHomeHref()}` for cross-page navigation. (HeaderGelato precedent.)
- **Section that renders only its header + an empty body when the store has no data** for it — counts as broken. Either hide the section (`if (items.length === 0) return null;`) or render a meaningful empty state pointing the vendor to the dashboard. (Phase 11d.)

---

## Reference files

- Config gold-standards: `configs/corporate/zam-events.ts`, `configs/food/gelados-premium.ts`.
- Section component precedent: `sections/industry/food/GelatoFlavorsGrid.tsx`, `sections/headers/HeaderGelato.tsx`, `sections/industry/restaurant/BrasaMenu.tsx`.
- WhatsApp handoff: `checkout/OrderConfirmation.tsx:17-20` + `lib/api/storefront.ts` → `getWhatsAppUrl()`.
- Color scheme injection pipeline: `lib/data/color-schemes.ts:581-601` → `colorTokensToCssVariables`.
- Cart provider: `providers/CartProvider.tsx` → `useCart()` exposes `itemCount`, `addItem`, `openSidebar`, `closeSidebar`.
- Nav helpers: `providers/StorefrontNavProvider.tsx` → `getHref`, `getHomeHref`, `getPageHref`, `isPlaceholder`, `isPreviewMode`.
- Content resolver: `lib/templates/helpers/site-content.ts` → `resolveContent(store, key, fallback)`.
