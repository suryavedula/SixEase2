# Lint Code

Run linters and formatters on the codebase.

## Instructions

1. If `$ARGUMENTS` is empty, lint everything:
   - Backend: `docker-compose exec backend ./mvnw checkstyle:check spotbugs:check`
   - Frontend: `docker-compose exec frontend npm run lint`

2. If `$ARGUMENTS` is "backend" or "api":
   - Run Java linting only

3. If `$ARGUMENTS` is "frontend" or "ui":
   - Run TypeScript/ESLint only

4. If `$ARGUMENTS` is "fix":
   - Auto-fix issues where possible
   - Backend: `docker-compose exec backend ./mvnw spotless:apply`
   - Frontend: `docker-compose exec frontend npm run lint -- --fix`

5. Report any issues found with file locations and descriptions
