# Review Task

Review a task that has been implemented.

## Instructions

1. Find the task file matching `$ARGUMENTS` in `kambam/in-progress/`
2. Read the task requirements and acceptance criteria
3. Review all code changes for this task:
   - Check SOLID principle compliance
   - Verify ACID compliance for transactions
   - Check design pattern usage
   - Verify error handling
   - Check for security issues (input validation, SQL injection, XSS)
   - Verify Portuguese language for user-facing content
4. Run relevant tests if they exist
5. Provide a review summary:
   - Acceptance criteria checklist
   - Code quality assessment
   - Issues found (if any)
   - Recommendations
6. If approved, move task to `kambam/review/`
