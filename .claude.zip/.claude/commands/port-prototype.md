---
name: port-prototype
description: Port an HTML prototype (under `prototype/{name}/`) into a real KitandaSmart template — config + components + mock data + every backend/admin/CMS integration point. Reads `manifest.json` for deterministic mapping; falls back to HTML audit when missing. Defers the heavy execution playbook to `/create-template`.
parameters:
  - name: prototypePath
    description: Path to the prototype directory (e.g., `prototype/padaria-artesanal`). Must contain at least `index.html`; ideally also `manifest.json` produced by `/create-prototype`.
    required: true
  - name: templateId
    description: Kebab-case template ID for the new KitandaSmart template (e.g., `padaria-artesanal`). Used as folder name, config key, URL param.
    required: true
  - name: industry
    description: TemplateIndustry value (FOOD, FASHION, RESTAURANT, etc.). If the manifest has one, this must match — surface a conflict instead of overriding.
    required: true
  - name: siteMode
    description: Backend SiteMode the template targets (LOJA, MENU, LANDING_CORPORATE, LANDING_PERSONAL, EDUCACAO, SERVICOS).
    required: true
  - name: colorSchemeId
    description: SCREAMING_SNAKE_CASE color scheme ID for the new scheme (e.g., `PADARIA_WARM`). If the prototype manifest has one, this overrides only if explicitly passed.
    required: false
---

# Port HTML Prototype → KitandaSmart Template

This skill is the **bridge**: takes a prototype directory and translates it into the inputs required by `/create-template`, then runs through the full integration playbook.

It does **not** duplicate `/create-template`. The execution checklist (KNOWN_TEMPLATES, registries, route folders, CMS slot-key parity, env vars, smoke tests) lives there. This skill's job is the **prototype-to-config translation** and **automatic extraction** of inputs that `/create-template` would otherwise ask the user for.

## When to use which

| Situation | Use |
|---|---|
| You have a prototype folder (HTML + manifest) and want a real template | `/port-prototype` (this skill) |
| You're starting from scratch with no prototype, or porting a Vite/React project that doesn't follow the create-prototype convention | `/create-template` directly |
| You want to generate a prototype HTML from refs first | `/create-prototype` |

---

## Step 1 — Read the prototype

1. **Verify the path exists** — abort with a clear message if `{prototypePath}/` doesn't exist or is empty.

2. **Read `manifest.json`** if present. The manifest is the source of truth for:
   - `industry`, `style`, `siteMode`, `siteModeHint`, `pages`, `navAnchors`
   - `colorScheme.tokens` (all 17), `colorScheme.id`, `colorScheme.name` (or top-level `colors` for blueprint manifests)
   - `fonts.body`, `fonts.display` (or top-level `typography` for blueprint manifests)
   - `sections.{page}` — list of `{ type, anchor, slots }` per page
   - `storeFields` — what comes from store settings (not slots)
   - `thirdPartyIntegrations` — env vars needed
   - **Blueprint fields** (set by `/prototype-loja` and future `/prototype-{mode}` skills):
     - `blueprint` — filename of the blueprint contract (e.g., `"loja.md"`). When present, **load and follow** that blueprint as a hard constraint.
     - `blueprintCompliance.requiredCore` — slots that must be locked into the template's `sections` field (vendor cannot disable).
     - `blueprintCompliance.platformMandatory` — `whatsapp-floating` + `mobile-bottom-nav` (must be wired regardless of manifest).
     - `blueprintCompliance.cmsDynamicBlocks[]` — each entry has `{ slot, variant, sourcedFrom, defaultEnabled, slotKeys[] }`. Every entry becomes a CMS-dynamic block in the template (component + registry + contentSlots + contentGroup + sectionGroupMap + visibility toggle).
     - `blueprintCompliance.hardDiscarded[]` — sections explicitly removed (platform locks). Do not re-introduce.

3. **If no manifest, audit the HTML**:
   - Read `index.html` and every `*.html` sibling.
   - Extract `data-section-type` attributes → section list per page.
   - Extract `data-content-slot` attributes → slot keys per section.
   - Extract `data-store-field` attributes → store-settings fields.
   - Parse `:root { --color-...: #...; }` from `style.css` → color token map.
   - Parse `<link href="https://fonts.googleapis.com/...">` → font list.
   - Surface gaps to the user before generating: missing slot keys, sections without types, color tokens that don't fill all 17 slots.

4. **Cross-check parameters vs manifest**: if `industry` parameter conflicts with `manifest.industry`, ask the user which to follow. Do not silently override. Same rule for `siteMode`.

---

## Step 1b — Blueprint enforcement (when `manifest.blueprint` is set)

When the manifest declares a blueprint (e.g., `"blueprint": "loja.md"` from `/prototype-loja`), open `frontend/lib/templates/blueprints/{blueprint}` and read it before doing anything else. The blueprint is the binding contract for the template; any conflict between manifest and blueprint resolves in favor of the blueprint.

Verify three invariants before continuing:

1. **Required core is complete.** The four locked slots (header, hero, featured-products, footer for LOJA) must each have an entry in `manifest.blueprintCompliance.requiredCore`. If any is missing, abort and ask the user to re-run `/prototype-{mode}` — do not silently invent slots at port time.

2. **Platform-mandatory wiring is planned.** `whatsapp-floating` and `mobile-bottom-nav` will be wired in Step 4 from the project's existing components — no manifest entry is required, but the smoke test in Step 7 depends on them.

3. **No hard-discarded section was reintroduced.** Cross-reference `manifest.blueprintCompliance.hardDiscarded[]` against the prototype's HTML — if a discarded section type is present in the markup, surface it and ask the user before continuing. Common cases: a language switcher snuck back into the header, a `siteMode`-mismatched section reappeared.

For LOJA-mode prototypes specifically, Section 8 of `loja.md` lists the required CMS slot keys the template MUST expose regardless of which CMS-dynamic blocks are enabled. Preload that list now — Step 3 uses it.

---

## Step 2 — Plan the port

Build a concrete plan and present it to the user as a numbered list **before** writing any files. This is the only mandatory user checkpoint in the skill — the prototype's section types may map to existing KitandaSmart components OR require new ones, and the user owns that decision.

For each section in the prototype, decide one of:

| Outcome | When | Action |
|---|---|---|
| **Reuse existing** | Section type is identical (visually + structurally) to an existing registry entry | Map to the existing `type` string in `INDUSTRY_REGISTRY` / `HEADER_REGISTRY` / etc. No new component. |
| **Create new** | Section is custom or is a `{templateId}-*` type | New component file + new registry entry + new TS interface in `types.ts`. |
| **Adapt with config** | Section is close to existing but needs a config flag the existing component doesn't expose | Either extend the existing component (preferred when generic) or fork as a new component (preferred when bespoke). |

Default per `feedback_template_fidelity.md`: **create new** when in doubt. Reuse only on 100% visual match.

Output the plan in this shape:

```
Port plan for templateId={templateId}:

Color scheme: PADARIA_WARM (new)
  ├─ Frontend types: 2 unions to extend
  └─ Backend enum: 1 value to add

Industry: FOOD (existing — no industry-level changes)

Sections (homepage):
  1. header-padaria          → NEW HeaderPadaria.tsx
  2. hero-padaria            → NEW HeroPadaria.tsx
  3. featured-products       → REUSE existing "featured" type
  4. padaria-locations       → NEW PadariaLocations.tsx
  5. footer-padaria          → NEW FooterPadaria.tsx

Sub-page route folders to create:
  - app/(storefront)/[store]/quem-somos/  (already exists — reuse)
  - app/(storefront)/[store]/locais/      (NEW)

Backend changes:
  - KNOWN_TEMPLATES.put("padaria-artesanal", ...)
  - ColorScheme.PADARIA_WARM (Java enum)

Mock data:
  - MOCK_PRODUCTS_PADARIA (8 items)
  - templateSiteContent["padaria-artesanal"] in createMockStoreForIndustry

Slot inventory: 23 slots across 4 groups (hero, about, locais, contact)
```

Wait for user confirmation. **Do not skip this step.** A "looks fine, proceed" reply is enough.

---

## Step 3 — Translate manifest to template config

Generate the `TemplateConfig` file at `frontend/lib/templates/configs/{industry}/{templateId}.ts`.

### Mapping rules

- **manifest.colorScheme** → `defaultColorScheme: "PADARIA_WARM"` + the new entry in `lib/data/color-schemes.ts` (use the manifest's 17 tokens directly).
- **manifest.fonts.display** → if non-Inter, add a `next/font` entry in `app/layout.tsx` and a `tailwind.config.ts` family entry (per `/create-template` Phase 3).
- **manifest.sections.homepage** → `sections: { header, hero, industry: [...], footer }` in the order the manifest lists them. Skip header/hero/footer entries from the `industry` array; they go in their own slots.
- **manifest.sections[other-page]** → entries under `pages.{slug}.sections`.
- **manifest.pages** → `pages: { ... }` config + matching route folder under `app/(storefront)/[store]/{slug}/`.
- **manifest.navAnchors** → `navAnchors: [...]`.
- **All slot keys** in `manifest.sections[*].slots` → `contentSlots: [...]` in the config. Group them logically into `contentGroups` (one group per major area: hero, about, page-{slug}, banners, contact).
- **manifest.storeFields** → don't make slots; instead use `sectionGroupMap` entries with `settingsForm: "contact"`.
- **manifest.thirdPartyIntegrations** → env vars to wire per `/create-template` Phase 8.

### Blueprint-aware mapping (when `manifest.blueprint` is set)

The blueprint manifest splits sections into three buckets. Each is wired differently in the `TemplateConfig`:

**`requiredCore[*]`** — these become the locked top-level `sections` slots (`header`, `hero`, `featured-products` mapped to whichever core slot the manifest defines, `footer`):

```ts
sections: {
  header:   { type: "{slot-component-type}", ...variantProps },
  hero:     { type: "{slot-component-type}", ...variantProps },
  industry: [ /* CMS-dynamic blocks land here in `defaultEnabled: true` order */ ],
  footer:   { type: "{slot-component-type}", ...variantProps },
}
```

The vendor visual editor must NOT expose enable/disable for required-core slots — they always render.

**`platformMandatory`** — `whatsapp` and `mobile` enter via the existing platform-level config keys (`sections.whatsapp` and `navigation.mobile`); they are inherited and don't need entries in the manifest's section list.

**`cmsDynamicBlocks[*]`** — for each block, do all of the following:

1. **Component**: Step 4 builds the component as usual. File goes under `components/storefront/sections/industry/{industry}/` (or `components/storefront/sections/blocks/` if shared cross-industry).

2. **Registry**: register the type string in `lib/templates/registry.ts` (or `page-registry.ts` if it's a sub-page block).

3. **`sections.industry[]` entry**: append the block to the homepage `industry` array in the order they appear in the manifest. Use the variant from `manifest.cmsDynamicBlocks[i].variant` to set component-specific props.

4. **`contentSlots`**: append every key in `cmsDynamicBlocks[i].slotKeys` to the config's `contentSlots`. Use the slot key verbatim — do NOT rename. Set `group` to a per-block group ID (e.g., `group: "block-social-proof"`).

5. **`contentGroups`**: register one entry per CMS-dynamic block — `{ id: "block-social-proof", label: "Testemunhos", description: "Bloco opcional na pagina inicial", icon: "Quote" }`. The label is what the vendor sees in the visual editor.

6. **`sectionGroupMap`**: add one entry per block to map the section to its editor card and to expose its `visible` toggle:

   ```ts
   "social-proof": {
     groupId: "block-social-proof",
     slotPrefix: ["social-proof."],
     label: "Testemunhos",
     // The editor reads `visible` from the section editor and the storefront skips render when false.
   }
   ```

7. **`defaultEnabled`** flag: append `sections.industry[i].visible = manifest.cmsDynamicBlocks[i].defaultEnabled` (default to `true` when omitted). The component's render guard reads this through the standard section-config plumbing — `if (config.visible === false) return null;` — so vendor disable means the block disappears from the storefront on the next page load.

The visual editor (admin slot-editor) already reads `sectionGroupMap`. Once steps 5–7 are done, every CMS-dynamic block automatically gets its own card in the editor with a Visible/Hidden toggle and edit fields for its slot keys. **Do not add bespoke editor UI per block** — the existing editor handles it.

### Slot-key parity check (LOJA only)

Section 8 of `loja.md` lists CMS slot keys every LOJA template MUST expose, regardless of which CMS-dynamic blocks are enabled:

```
hero.title, hero.subtitle, hero.image, hero.cta.text, hero.cta.link
featured.title
about.short, about.image
contact.address, contact.phone, contact.whatsapp, contact.email, contact.hours
footer.text, footer.legal
seo.home.title, seo.home.description
seo.produtos.title, seo.produtos.description
```

After Step 3, diff this list against the generated `contentSlots`. Any missing key gets added with a sensible default (don't wait for the smoke test in Step 7 to surface it).

### Slot grouping defaults

| Manifest slot prefix | Group | Group label |
|---|---|---|
| `hero.*`, `home.*` | `hero` | "Página Inicial" |
| `about.*` | `about` | "Quem Somos" |
| `page.{slug}.*` (per page) | `{slug}` | "Textos {Page Title}" |
| `page.{slug}.banner` | `banners` | "Banners" |
| `page.contactar.*`, `contact.*` | `hero` | (folded in) |

---

## Step 4 — Generate components

For every "NEW" section in the plan:

1. Create `components/storefront/sections/{family}/{Component}.tsx` (family = `headers`, `heroes`, `footers`, or `industry/{industry}`).
2. Translate the prototype's section markup into JSX:
   - Replace hardcoded text with `resolveContent(store, "{slot.key}", "fallback")`.
   - Replace `data-content-slot="hero.backgroundImage"` `<img src="...">` with `resolveContent`-driven src + lazy loading.
   - Replace hex colors with `var(--color-...)` references (already in CSS vars from step 1 — Tailwind classes like `bg-[var(--color-primary)]` work fine).
   - Replace static `<a href="/products">` with `useStorefrontNav().getHref("/products")`.
   - Replace `+244...` phone with `store.contact?.whatsappNumber || store.contact?.phone`.
   - Replace WA links with `getWhatsAppUrl(phone, message)` from `@/lib/api/storefront`.
   - Replace `<button>Adicionar</button>` carts with `useCart().addItem(...)`.
   - Add `data-store-field` placeholders → real fields from the store entity.
3. Use `"use client";` at the top, accept `SectionProps<TConfig>` (homepage) or `PageSectionProps` (sub-pages).
4. Use `formatPrice(product.price)` from `@/lib/templates/helpers`. Never hardcode `"Kz"`.
5. All copy stays Portuguese.

Register every new component in `lib/templates/registry.ts` (homepage sections) or `lib/templates/page-registry.ts` (sub-page sections).

For reused components, no new file — just confirm the existing component renders correctly when fed the prototype's section config.

---

## Step 5 — Mock data

Translate prototype content into mock data so `/preview?templateId={id}` shows the prototype faithfully:

1. **Products** (if the prototype shows specific products, e.g., a bakery menu):
   - Add `MOCK_PRODUCTS_{NAME}` + `MOCK_PAGINATED_PRODUCTS_{NAME}` in `lib/templates/mock-data.ts`.
   - Wire dispatchers: `getMockProductsForTemplate(templateId)` and `getMockFeaturedProductsForTemplate(templateId)`.
2. **Site content slots**: add `MOCK_SITE_CONTENT_{NAME}` with values pulled from the prototype HTML (the actual text the user wrote in the prototype). Wire it in `createMockStoreForIndustry` under `templateSiteContent[templateId]`.
3. **Portfolio / testimonials / locations** — only if the prototype uses them.
4. If `industry` is new globally, add `INDUSTRY_NAMES[industry]` and `INDUSTRY_DESCRIPTIONS[industry]`.

---

## Step 6 — Hand off to `/create-template`'s execution playbook

The remaining integration points (KNOWN_TEMPLATES, INDUSTRY_TABS, slot-key parity, smoke tests, etc.) are exhaustively documented in `/create-template`. **Do not duplicate** that work — execute it by reference.

Concretely, run through the master checklist at the bottom of `.claude/commands/create-template.md`:

- Foundations (color scheme triple-sync — frontend × 2 + backend Java enum)
- Components + registries (already covered above for new ones)
- Sub-page route folders (Next.js static folders — slug in config alone is NOT enough)
- Mock data (already covered above)
- Backend (`KNOWN_TEMPLATES`, `StoreType`, `inferSiteMode`)
- Admin (`INDUSTRY_TABS` if industry is new)
- CMS (`ICON_MAP`, slot-key parity, `SECTION_ANCHORS` for in-page anchors)
- Env vars (only if third-party)
- Smoke tests (preview, regression on neighbors, type-check, lint, dashboard CMS, onboarding flow, admin)

The single most-forgotten step from prior templates (HOXI, ZAM, Nexus precedents) is **`KNOWN_TEMPLATES` in `AdminTemplateService.java`**. Add it in this skill's run before declaring done.

---

## Step 7 — Smoke test before reporting done

Mandatory checks (full list in `/create-template` Phase 9):

- [ ] `/preview?templateId={templateId}` renders cleanly in the browser; no console errors.
- [ ] Each sub-page in `pages` has a route folder + renders.
- [ ] **Visual diff against the prototype** — open `prototype/{name}/index.html` and `/preview?templateId={templateId}` side by side. Sections must match in order, layout, color, type. If they don't, the port is incomplete.
- [ ] `npm run type-check` adds zero new errors.
- [ ] Slot-key parity: every `resolveContent()` call in new components matches a key in `contentSlots`.
- [ ] CMS smoke: `/content/cms/{group}` opens, edit a slot, save, refresh preview, change applies.
- [ ] Onboarding: template appears under the industry filter (`/create-template` Phase 9 step 7).
- [ ] Admin: template appears in `/admin/templates` under the right industry tab.

### Blueprint smoke (when `manifest.blueprint` is set)

Additional checks specific to blueprint-aware templates:

- [ ] **Required-core lock**: try toggling `header`/`hero`/`featured-products`/`footer` "off" in the section editor. The editor should not allow it (or the storefront must keep rendering them regardless).
- [ ] **CMS-dynamic toggle**: for each block in `manifest.blueprintCompliance.cmsDynamicBlocks`, the section editor shows a Visible/Hidden toggle. Disabling makes the block disappear from `/preview` after refresh; re-enabling brings it back.
- [ ] **CMS-dynamic edit**: for each block, edit one of its `slotKeys` in the editor, save, refresh preview — change applies in the right block.
- [ ] **Blueprint-required slot keys**: `loja.md` §8 list is fully present in `contentSlots`. Run a quick grep / diff to confirm.
- [ ] **Hard-discarded sections**: confirm none of the `hardDiscarded[]` types render anywhere on the storefront (search the rendered HTML for any forbidden type).
- [ ] **Platform-mandatory**: floating WhatsApp button visible on every page; mobile bottom nav visible at <768px viewport.

---

## Output to user

After completion, post:
- Files created (count + paths).
- Files modified (config registry, mock-data, registries).
- Backend touchpoints completed.
- Smoke-test status (what passed, what to verify manually — especially the visual diff).
- Anything the prototype implied but the port didn't cover (e.g., a section type that needs follow-up because the existing component doesn't quite match — flag it explicitly, do not silently substitute).

---

## Anti-patterns specific to porting

- **Silent substitution** — porting a `hero-padaria` to the existing `hero-banner` component "because it's similar." If the prototype has a custom hero, the template needs a custom hero. The whole point of the prototype-create flow is to lock this decision early.
- **Skipping the plan checkpoint in Step 2** — the user must see and approve the section reuse-vs-new map before generation.
- **Trusting the manifest blindly when references conflict** — if the HTML has 5 sections and the manifest claims 6, audit the HTML and surface the discrepancy.
- **Re-deriving colors instead of copy-pasting from the manifest** — the manifest is the source of truth; sampling from screenshots again invites drift.
- **Generating the template config without reading at least one existing config** — `configs/food/gelados-premium.ts` and `configs/corporate/zam-events.ts` are the gold-standards for shape and conventions.
- **Treating CMS-dynamic blocks as required core** — when `manifest.cmsDynamicBlocks[i].defaultEnabled` is `false`, the block must START hidden in the storefront and the visual editor must offer the toggle to enable it. Skipping the visibility plumbing means vendors lose the opt-in/out promise.
- **Hardcoding a CMS-dynamic block's content** — every editable field MUST go through `resolveContent()` against the manifest's `slotKeys`. Hardcoding "Free shipping in Luanda" defeats the CMS-dynamic premise.
- **Renaming slot keys at port time** — the manifest's keys are the contract with the prototype. Renaming `social-proof.item1.quote` to `testimonial-1-text` breaks the editor's pre-built form for that block type.
- **Forgetting `sectionGroupMap` for new CMS-dynamic blocks** — without it, the block has no card in the visual editor and the slot keys appear in a generic bucket rather than a labeled per-block group.

---

## Reference files

- `/create-template` — master playbook for all integration points (KNOWN_TEMPLATES, registries, route folders, CMS, env vars, smoke tests).
- `/create-prototype` — generates the prototype this skill ingests.
- `frontend/lib/templates/COOKBOOK.md` — narrative template authoring guide.
- `frontend/lib/templates/configs/food/gelados-premium.ts` — gold-standard multi-page template config.
- `frontend/lib/templates/configs/corporate/zam-events.ts` — gold-standard CMS-heavy config.
- `memory/project_template_positioning_angola.md` — Angola mobile-first positioning constraint.
- `memory/feedback_template_fidelity.md` — never substitute close-enough components for prototype sections.
- `memory/feedback_template_hidden_wiring.md` — silent-fail integration points.
