# Complete Task

Mark a task as completed and move it to done.

## Instructions

1. Find the task file matching `$ARGUMENTS` in `kambam/review/` or `kambam/in-progress/`
2. Verify all acceptance criteria have been met
3. Ensure tests pass (if applicable)
4. Move the task file to `kambam/done/`
5. Update the task file with:
   - Completion date
   - Summary of what was implemented
   - Any notes for future reference
6. List any follow-up tasks that should be created
