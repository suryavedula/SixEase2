---
name: create-prototype
description: Generate a fully working Vite + React + Tailwind + Motion prototype from references (images, Shopify HTML, freeform description). Includes complete animations, hover/scroll/page transitions, mobile-first Angola positioning, machine-readable manifest for /port-prototype. Discards Shopify/Western patterns that don't fit the Angola mobile-only market.
parameters:
  - name: name
    description: Kebab-case prototype folder name (e.g., `padaria-artesanal`, `farmacia-bairro`). Becomes `prototype/{name}/` at repo root.
    required: true
  - name: references
    description: References for inspiration. Can be image paths, HTML/Vite project paths, URLs, or a freeform description. Provide multiple as a list. The skill reads images/HTML, extracts layout, color palette, sections, and animation cues.
    required: true
  - name: industry
    description: TemplateIndustry the prototype targets — FASHION, BEAUTY, PHARMACY, HARDWARE, RESTAURANT, SERVICES, EDUCATION, CORPORATE, PERSONAL, FOOD.
    required: true
  - name: style
    description: Visual style hint — `classic`, `modern`, `bold`, `premium`. Defaults to `modern`.
    required: false
  - name: pages
    description: Comma-separated sub-page slugs beyond the homepage (e.g., `quem-somos,servicos,contactos`). Each becomes a route component. Default is homepage only.
    required: false
---

# Create KitandaSmart-Portable Prototype

Generate a **fully working Vite + React + Tailwind v4 + Motion prototype** that matches the convention of every existing prototype in `prototype/` (maz-template, kindala-webpage, unistore1, nd-digital, gelado1, Template-X-shop). Not a static HTML wireframe — a real React app with **complete animations, hover states, scroll-triggered reveals, page transitions, custom CSS keyframes**, ready to `npm install && npm run dev`.

The output is the **review artifact** the user looks at before committing to a port. It must look and feel finished, not skeletal.

## Why this skill exists

Without a convention, prototypes vary wildly: Shopify HTML exports, Figma static dumps, ChatGPT snippets, hand-rolled HTML. Every port re-does the audit. This skill front-loads the decisions:

- Section markers (`data-section-type`, `data-content-slot`) make `/port-prototype` mechanical.
- 17-token CSS variable shape mirrors KitandaSmart's `ColorScheme` so the port becomes "copy the manifest into `lib/data/color-schemes.ts`."
- Animation patterns match what KitandaSmart's section components already use (Motion's `whileInView` + `initial/animate` for scroll reveals; Tailwind transitions for hover; CSS `@keyframes` for marquees, drips, custom decorations).
- Built-in trim of Shopify/Western patterns that don't fit Angola's mobile-only market.

---

## Stack — match the existing prototypes exactly

Every prototype under `prototype/` uses this stack. Do not deviate without explicit user instruction:

| Piece | Version | Why |
|---|---|---|
| Vite | ^6 | Dev server with HMR; matches the `vite-plugin-react` conventions of all existing prototypes |
| React | ^19 | Same as existing prototypes |
| TypeScript | ~5.8 | Same |
| Tailwind v4 | ^4.1 | Uses `@theme {}` block in `index.css` for design tokens — **not** a `tailwind.config.ts` file |
| `@tailwindcss/vite` | ^4.1 | Tailwind v4 Vite plugin (no PostCSS config needed) |
| `motion` | ^12 | Replaces Framer Motion. Imported as `import { motion } from 'motion/react'`. Used for scroll reveals, page transitions, hover micro-animations |
| `lucide-react` | ^0.546 | Icon library |
| `react-router-dom` | ^7 | Only when `pages` parameter is non-empty (multi-page prototypes) |

**Reference prototypes** to study before generating — read at least one before writing code:
- `prototype/maz-template-main/` — multi-page, gold standard for Motion usage (`whileInView`, staggered reveals, page transitions)
- `prototype/kINDALA-WEBPAGE-main/` — single-page brutalist; CSS noise overlay, marquee, text-stroke, crosshair grid in `index.css`
- `prototype/uniStore1-main/` — e-commerce with cart drawer (transform translate transitions), mega-menu, focus-within rings
- `prototype/gelado1-main(1)/` — drip-SVG hero separator, custom font (Bubblegum Sans), pink/yellow palette

---

## Inputs

References can be any combination:

- **Screenshot images** under `prototype/refs/` or `~`. Read with the Read tool (multimodal). Extract: layout structure, color palette, typography hierarchy, decorative motifs (gradients, noise, drips), animation cues (parallax, hover hints, scroll behaviors).
- **HTML / Vite project paths** — read source files. Extract sections, color tokens, motion patterns, custom CSS.
- **URLs** — use WebFetch.
- **Freeform description** — "single-page bakery, warm beige + brown, hero with bread photo, then product grid, then locations on a map, sticky bottom WA CTA."

If references conflict (one says light theme, another dark), ask which to follow — do not average.

---

## Step 1 — Inventory + filter references

Before code, build an explicit list:

### 1a. Sections per page

Tag with one of these section-type strings (KitandaSmart-aligned):

| Family | Existing types | When custom |
|---|---|---|
| Header | `header-minimal`, `header-centered`, `header-split`, `header-transparent`, `header-ecommerce`, `header-restaurant`, `header-premium` | Custom: `header-{templateId}` when layout is bespoke |
| Hero | `hero-banner`, `hero-split`, `hero-video`, `hero-carousel`, `hero-fullscreen`, `hero-minimal`, `hero-premium` | Custom: `hero-{templateId}` |
| Industry | `featured-products`, `category-grid`, `menu-section`, `mvv`, `team-grid`, `services-list`, `stats-counter`, `testimonials`, `cta-band`, `contact-section`, `differentials` | Custom: `{templateId}-{descriptor}` |
| Footer | `footer-simple`, `footer-contact`, `footer-corporate`, `footer-premium` | Custom: `footer-{templateId}` |
| Mobile | `bottom-tabs`, `whatsapp-floating` | Always reuse — these are platform standard |

Default to **custom** when the prototype's section is not a 100% match (per `feedback_template_fidelity.md`).

### 1b. Discard list — Shopify/Western patterns to DROP for Angola

When ingesting Shopify themes, Western e-commerce sites, or "premium template marketplace" references, **strip these aggressively**. They add weight, hurt 3G load times, and confuse mobile-only users unfamiliar with web e-commerce conventions:

| Pattern | Why drop | What to use instead |
|---|---|---|
| **Email newsletter signup** | Low conversion in Angola; WhatsApp is the channel | WhatsApp CTA |
| **"Subscribe and get 10% off" popup** | Modal interruptions kill mobile UX | None — direct discount in product card |
| **Multi-step credit-card checkout** | Multicaixa Express + WhatsApp handoff, not Stripe | Existing checkout flow |
| **Multi-currency switcher** | Single currency (Kz) | Drop entirely |
| **Multi-language toggle (EN/FR/ES)** | Portuguese-only platform | Drop |
| **Live chat widget** (Intercom, Drift, Tidio) | Floating WhatsApp does the same job, cheaper | `whatsapp-floating` |
| **Cookie consent banner** | PWA scope; simpler legal model | Drop unless explicitly required |
| **Account/login-gated sections** | Passwordless SMS only on KitandaSmart | Public + WA-gated |
| **Mega-menu with 4–5 columns** | Cluttered on mobile; vendor catalogs are small | Single-row pill nav or hamburger |
| **Hero carousel with 4+ slides** | Auto-rotate hurts attention; mobile users don't dwell | Single static hero |
| **"As seen on" press logo strip** | No press relevance | Drop or replace with partner/client logos |
| **Blog teaser block on homepage** | Most vendors don't blog | Drop unless `features.blog: true` |
| **Free-shipping countdown bar** | Delivery is local; no national shipping | Drop |
| **Wishlist / save-for-later** | Cart-only model is simpler | Drop |
| **Shipping calculator widget** | Local zones are flat-rate | Static delivery info card |
| **Size-guide popup modals** | Industry-specific (FASHION/BEAUTY only) — drop everywhere else | Inline accordion when needed |
| **Reviews aggregator with star schema microdata** | Premature; testimonials section suffices | `testimonials` |
| **Trustpilot / BBB / verified badges** | Foreign trust signals | Local trust: WhatsApp number, physical address |
| **Currency converter widget** | Single-currency platform | Drop |
| **Multi-step product configurator** (build-your-own) | Niche; WhatsApp consultation handles bespoke orders | WhatsApp deep-link with product context |
| **"Recently viewed products"** | Cookie-driven personalization is overhead for low-RAM devices | Drop |
| **Footer with 4 link columns** (Help, About, Shop, Connect) | Collapses awkwardly on mobile | Single column or 2 short columns |
| **Press carousel / testimonials with 6+ entries auto-scrolling** | Heavy DOM; one or two static testimonials are enough | 2–3 static testimonials |
| **Loyalty / points / referral program section** | Out-of-scope feature | Drop |
| **"Gift card" purchase flow** | Niche | Drop unless explicitly needed |
| **Animated scroll progress bar at top** | Distracting on mobile | Drop |
| **Custom cursor effects** | Mouse-only; mobile users don't see | Drop |
| **Heavy parallax with multiple layers** | GPU-intensive on 2GB devices | Single-layer parallax max |
| **Video autoplay with sound** | Bandwidth + UX hostile | Muted, lazy-loaded, or drop |
| **Sticky announcement bar with promo code** | Wastes vertical space; mobile real estate is precious | Inline in hero CTA |
| **"Quick view" product modal** | Adds tap depth without value | Direct product page |
| **Instagram feed embed** | API-fragile, slow | Static gallery + social link in footer |

**The trim is non-negotiable.** Note every dropped pattern in `manifest.notes` so the user knows it was intentional.

### 1c. Color tokens

Extract unique colors. Map to the 17-token shape. Do not extend.

```
primary, primaryForeground, secondary, secondaryForeground,
accent, accentForeground, background, foreground,
muted, mutedForeground, card, cardForeground, border,
destructive, destructiveForeground, success, successForeground
```

Defaults when references don't show: `success: #16A34A`, `destructive: #DC2626`. Extra prototype colors → derive at call site with `color-mix(in srgb, var(--color-primary) 85%, black)`.

### 1d. Fonts

`Inter` body default. Display fonts go in `index.css` `@theme` block + `<link>` tag.

### 1e. Editable content (slot keys) — same conventions as before

`hero.title`, `hero.subtitle`, `hero.primaryCtaText`, `hero.primaryCtaUrl`, `hero.backgroundImage`, `home.{section}.{field}`, `about.{field}`, `page.{slug}.{field}`, `page.{slug}.banner`, `page.{slug}.differentials.item{N}.{field}`, `page.contactar.{field}`.

Store-settings fields (phone, email, hours, address, socials, logo) → mark with `data-store-field`, NEVER as slots.

### 1f. Animations to plan

For each section, decide which animation patterns apply. The prototype must include AT LEAST these baseline animations (all using `motion/react` or CSS keyframes):

| Pattern | When | Implementation |
|---|---|---|
| **Hero entry** | First viewport on load | `motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}` |
| **Staggered hero children** | Hero subtitle + CTAs | Add `delay: 0.2`, `0.4` to subsequent `motion.div` |
| **Scroll-triggered reveals** | Every section below the hero | `motion.div initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-100px" }} transition={{ duration: 0.6 }}` |
| **Card hover lift** | Product / service / team cards | Tailwind: `hover:-translate-y-1 hover:shadow-xl transition-transform duration-300` |
| **Image zoom on hover** | Product images, portfolio thumbs | `<img className="transition-transform duration-500 group-hover:scale-105">` inside `group` parent |
| **CTA hover shimmer** | Primary buttons | Tailwind: `hover:bg-[color-mix(in_srgb,var(--color-primary)_85%,black)] active:scale-[0.98] transition-all` |
| **Marquee** | Brand strips, announcement-style | CSS `@keyframes marquee` in `index.css` + `animate-marquee` utility |
| **Sticky header shadow on scroll** | Headers with `sticky` | `useState + useEffect` listening on `window.scroll`, toggle `shadow-md` class |
| **Mobile drawer** | Hamburger / cart drawer | `transform transition-transform duration-300 ${open ? 'translate-x-0' : 'translate-x-full'}` (precedent: `unistore1/CartComponents.tsx`) |
| **Page transitions** | Multi-page only | Wrap routes in `<AnimatePresence>` with `motion.div` per page; `initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}` |
| **Smooth scroll** | Anchor links | `html { scroll-behavior: smooth; }` in `index.css` |
| **Skeleton / shimmer placeholder** | Loading states (only if prototype shows them) | CSS keyframe `@keyframes shimmer` with linear-gradient |
| **Custom decorations** | Drip SVG (gelato), noise overlay (kindala), text-stroke (kindala), crosshair grid | CSS in `index.css` — see `prototype/kINDALA-WEBPAGE-main/src/index.css` for `.bg-noise`, `.text-stroke`, `.crosshair-grid` |

If the reference shows a specific animation (parallax, GSAP-style, scroll-driven SVG morph), implement it. **Do not generate static-looking sections** — every section should have entry animation, hover state, and at least one micro-interaction.

### 1g. Sub-pages + anchors

If multi-page, list each slug + page title. Record any `#anchor` IDs the nav points at.

---

## Step 2 — Generate the project

Create `prototype/{name}/` with this exact structure (matches existing prototypes):

```
prototype/{name}/
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── README.md
├── manifest.json                    # Port hints (read by /port-prototype)
└── src/
    ├── main.tsx
    ├── App.tsx
    ├── index.css                    # Tailwind v4 @theme + custom keyframes + utilities
    ├── data.ts                      # All editable content (slot-keyed)
    ├── components/
    │   ├── Header{...}.tsx
    │   ├── Hero{...}.tsx
    │   ├── Footer{...}.tsx
    │   ├── {SectionName}.tsx        # one file per industry section
    │   ├── WhatsappFloating.tsx
    │   └── ScrollToHash.tsx         # for anchor scroll on multi-page
    └── pages/                        # only when multi-page
        ├── HomePage.tsx
        ├── {Slug}Page.tsx
```

### `package.json` (copy-pasteable, matches existing)

```json
{
  "name": "{name}-prototype",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.0",
    "react-dom": "^19.0.0"
    {{, "react-router-dom": "^7.14.0"  // only if multi-page}}
  },
  "devDependencies": {
    "@tailwindcss/vite": "^4.1.14",
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0",
    "@vitejs/plugin-react": "^5.0.4",
    "autoprefixer": "^10.4.21",
    "tailwindcss": "^4.1.14",
    "typescript": "~5.8.2",
    "vite": "^6.2.0"
  }
}
```

### `vite.config.ts`

```ts
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: { '@': path.resolve(__dirname, '.') } },
});
```

### `index.html`

```html
<!doctype html>
<html lang="pt-PT">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{Display Name} — Protótipo</title>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/src/main.tsx"></script>
</body>
</html>
```

### `src/index.css` — Tailwind v4 + tokens + animations

Use `@theme {}` block (Tailwind v4 convention — NOT a `tailwind.config.ts` file). Define all 17 color tokens + display fonts + custom keyframes + custom utilities.

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
{{additional font @import lines}}
@import "tailwindcss";

@theme {
  --color-primary: #DC2626;
  --color-primary-foreground: #FFFFFF;
  --color-secondary: #FED7AA;
  --color-secondary-foreground: #7C2D12;
  --color-accent: #F97316;
  --color-accent-foreground: #FFFFFF;
  --color-background: #FFFBF5;
  --color-foreground: #1C1917;
  --color-muted: #FEF3E2;
  --color-muted-foreground: #78716C;
  --color-card: #FFFFFF;
  --color-card-foreground: #1C1917;
  --color-border: #FECACA;
  --color-destructive: #DC2626;
  --color-destructive-foreground: #FFFFFF;
  --color-success: #16A34A;
  --color-success-foreground: #FFFFFF;

  --font-sans: "Inter", ui-sans-serif, system-ui, sans-serif;
  {{--font-display: "Bricolage Grotesque", serif;}}

  --animate-marquee: marquee 30s linear infinite;
  --animate-shimmer: shimmer 2s linear infinite;
  --animate-drip: drip 6s ease-in-out infinite;
}

html { scroll-behavior: smooth; }
body {
  background-color: var(--color-background);
  color: var(--color-foreground);
  font-family: var(--font-sans);
  -webkit-font-smoothing: antialiased;
}

/* Custom keyframes — include every animation the prototype actually uses */
@keyframes marquee {
  0%   { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}

@keyframes shimmer {
  0%   { background-position: -1000px 0; }
  100% { background-position: 1000px 0; }
}

@keyframes drip {
  0%, 100% { transform: translateY(0); }
  50%      { transform: translateY(8px); }
}

@keyframes fade-in-up {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* Custom utilities — only what the prototype actually needs.
   Examples (drop the ones you don't use): */

/* Noise texture overlay (kindala precedent) */
.bg-noise::before {
  content: "";
  position: absolute; inset: 0; pointer-events: none; z-index: 0;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  opacity: 0.04;
}

/* Text stroke effect (premium templates) */
.text-stroke {
  -webkit-text-stroke: 1px rgba(0,0,0,0.3);
  color: transparent;
}

/* Marquee container (paired with --animate-marquee) */
.animate-marquee {
  animation: var(--animate-marquee);
  display: inline-flex;
  white-space: nowrap;
}
```

### `src/main.tsx`

```tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
```

### `src/data.ts` — every editable string in one place

```ts
export const content = {
  brand: {
    name: "Padaria Exemplo",
    whatsapp: "244923000000",
    address: "Luanda, Angola",
    email: "info@exemplo.ao",
  },
  hero: {
    title: "Pão fresco todos os dias",                  // slot: hero.title
    subtitle: "Massa lenta, ingredientes locais",        // slot: hero.subtitle
    primaryCtaText: "Encomendar",                        // slot: hero.primaryCtaText
    primaryCtaUrl: "#produtos",                          // slot: hero.primaryCtaUrl
    backgroundImage: "https://picsum.photos/seed/padaria-hero/1920/1080",
  },
  // ...one block per section, slot keys as comments
};
```

Comment each value with its slot key — `/port-prototype` reads `data.ts` to extract slot defaults for `MOCK_SITE_CONTENT_*`.

### `src/App.tsx` — wire everything

Single-page version (no `react-router-dom`):

```tsx
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Products } from './components/Products';
import { Footer } from './components/Footer';
import { WhatsappFloating } from './components/WhatsappFloating';

export default function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Products />
        {/* ...other sections in order */}
      </main>
      <Footer />
      <WhatsappFloating />
    </div>
  );
}
```

Multi-page: use `BrowserRouter` + `Routes` + `<AnimatePresence>`. See `prototype/maz-template-main/src/App.tsx`.

### Section components — full code with animations

Each section is a complete React component with:

1. `data-section-type="..."` on the root element.
2. `data-content-slot="..."` on every element rendering editable content.
3. `data-store-field="..."` on every element rendering store-settings content.
4. Motion entry animation on the root or main inner block (`whileInView` for non-hero, `animate` for hero).
5. Hover/focus states on every interactive element.
6. CSS variables for colors (`bg-[var(--color-primary)]`, `text-[var(--color-foreground)]`).
7. Lazy-loaded below-the-fold images (`loading="lazy"`).
8. Portuguese copy throughout.

Example shape (Products section):

```tsx
import { motion } from 'motion/react';
import { content } from '../data';

const products = [
  { id: "p1", name: "Pão de Forma", price: 800, image: "https://picsum.photos/seed/pao1/600/600" },
  { id: "p2", name: "Croissant", price: 500, image: "https://picsum.photos/seed/cro1/600/600" },
  // ...
];

export function Products() {
  return (
    <section
      id="produtos"
      data-section-type="padaria-products"
      className="py-16 md:py-24 bg-[var(--color-background)]"
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2
            data-content-slot="home.products.title"
            className="text-3xl md:text-5xl font-bold text-[var(--color-foreground)]"
          >
            Os Nossos Produtos
          </h2>
          <p
            data-content-slot="home.products.subtitle"
            className="mt-3 text-[var(--color-muted-foreground)] text-lg"
          >
            Frescos, todos os dias
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {products.map((p, i) => (
            <motion.a
              key={p.id}
              href={`#produto-${p.id}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="group block bg-[var(--color-card)] rounded-2xl overflow-hidden border border-[var(--color-border)] hover:-translate-y-1 hover:shadow-xl transition-all duration-300"
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={p.image}
                  alt={p.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-3 md:p-4">
                <h3 className="font-semibold text-[var(--color-card-foreground)]">{p.name}</h3>
                <p className="text-[var(--color-primary)] font-bold mt-1">
                  {p.price.toLocaleString("pt-PT")} Kz
                </p>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
```

This is the **minimum** density. Every section in the prototype must be this complete or richer. Skeleton sections with TODO placeholders are not acceptable.

### `manifest.json` — port hints (same shape as before)

```json
{
  "name": "{name}",
  "industry": "FOOD",
  "style": "modern",
  "siteModeHint": "LOJA",
  "stack": "vite-react-tailwind4-motion",
  "colorScheme": {
    "id": "PADARIA_WARM",
    "name": "Padaria Quente",
    "description": "Bege quente com castanho terroso para padarias artesanais",
    "tokens": { /* all 17 */ },
    "preview": { "primary": "#DC2626", "secondary": "#FED7AA", "accent": "#F97316" }
  },
  "fonts": { "body": "Inter", "display": null },
  "pages": [
    { "slug": "/", "file": "src/pages/HomePage.tsx", "title": "Início" }
  ],
  "sections": {
    "homepage": [
      { "type": "header-padaria",   "anchor": null, "slots": [] },
      { "type": "hero-padaria",     "anchor": null, "slots": ["hero.title","hero.subtitle","hero.primaryCtaText","hero.primaryCtaUrl","hero.backgroundImage"] },
      { "type": "padaria-products", "anchor": "produtos", "slots": ["home.products.title","home.products.subtitle"] },
      { "type": "footer-padaria",   "anchor": null, "slots": ["footer.tagline"] }
    ]
  },
  "navAnchors": [
    { "label": "Produtos", "anchorId": "produtos" }
  ],
  "storeFields": ["phone","whatsappNumber","address","email"],
  "thirdPartyIntegrations": [],
  "animations": [
    "motion-scroll-reveal", "card-hover-lift", "image-zoom-on-hover",
    "smooth-scroll", "sticky-header-shadow"
  ],
  "discardedFromReferences": [
    "Removed Shopify newsletter signup block — Angola uses WhatsApp",
    "Removed currency switcher — Kz only",
    "Trimmed hero carousel from 5 slides to 1 static",
    "Dropped 4-column footer for single-column on mobile"
  ],
  "notes": [
    "Source references: prototype/refs/padaria-{1,2,3}.png",
    "Modeled after: maz-template-main animation density",
    "Custom utilities used: bg-noise (kindala-style), animate-drip"
  ]
}
```

### `README.md`

```markdown
# {Name} — Protótipo KitandaSmart

**Industry:** {industry}
**Style:** {style}
**Stack:** Vite + React 19 + Tailwind v4 + Motion

## Como ver
```bash
cd prototype/{name}
npm install
npm run dev   # → http://localhost:3000
```

## Páginas
- `/` — Homepage com {N} secções

## Animações incluídas
{list from manifest.animations}

## Padrões descartados das referências
{summary from manifest.discardedFromReferences}

## Port para KitandaSmart
```
/port-prototype prototype/{name} {templateId} {industry} {siteMode}
```
O manifest cobre section types, color tokens, slot keys, animations e os trims feitos.
```

---

## Step 3 — Apply Angola-mobile-first positioning (non-negotiable)

See `memory/project_template_positioning_angola.md`. Hard rules:

- **Default ≤5 sections on homepage**: hero, category/nav, product showcase, trust strip, contact/WA. Add only if reference clearly demands.
- **Mobile-first at 360px**, layer desktop with `md:` breakpoint.
- **Single-screen hero**, no rotating carousel with 4+ slides.
- **Sticky bottom CTA** on mobile (`whatsapp-floating` or `bottom-tabs`).
- **Tap targets ≥ 48×48px**, body type ≥ 16px on mobile.
- **3G budget**: lazy-load below-the-fold images, no autoplay video, no 2MB hero JPG (resize to 1920×1080 max via `picsum.photos`).
- **No custom cursors, no parallax stacks**, no scroll-jacking.

If a Shopify reference has 8 sections, **trim to 4–5** during generation. Note every cut in `manifest.discardedFromReferences`.

---

## Step 4 — Self-verify before reporting done

Run through these checks (don't skip):

- [ ] `cd prototype/{name} && npm install && npm run dev` starts without errors at `localhost:3000`.
- [ ] Mobile view at 360px is the hero experience; desktop is enhancement.
- [ ] Every `<section>` and major block has `data-section-type`.
- [ ] Every editable string/image/URL has `data-content-slot` OR `data-store-field`.
- [ ] All colors come from `var(--color-*)`; no inline hex outside `index.css` `@theme {}` and `keyframes`.
- [ ] Hero has entry animation (`motion.* initial→animate`).
- [ ] Every below-the-fold section has scroll reveal (`whileInView`).
- [ ] Every product/card/clickable has hover state (transform, shadow, color, or scale).
- [ ] If multi-page: `<AnimatePresence>` wraps routes, smooth scroll on anchors.
- [ ] `manifest.json` validates as JSON; section types match the DOM `data-section-type` attributes; `discardedFromReferences` lists every Shopify pattern dropped.
- [ ] All copy is Portuguese.
- [ ] All placeholder images use `picsum.photos/seed/{stable-key}/...`.
- [ ] `tsc --noEmit` (lint script) passes.

---

## Anti-patterns

- **Skeletal sections with TODOs** — every section is fully built or it doesn't ship. Use `prototype/maz-template-main` density as the floor.
- **Static HTML output** — the convention is Vite + React + Motion; do not regress to plain HTML "for speed."
- **Hardcoded hex inside section markup** — use CSS vars; the porter then becomes a one-line color-scheme paste.
- **Generating from Shopify references verbatim** — the result feels foreign on Angola phones. Apply the discard list aggressively.
- **Reusing the same `data-section-type` for visually-different sections** — section types lock porting decisions.
- **No animations or all `transition-colors` only** — KitandaSmart's premium templates use `motion.*` extensively. Match that density.
- **Skipping the manifest** — without it, `/port-prototype` re-audits the HTML/JSX and may guess wrong on slot keys, animations, or trims.
- **Designing first for desktop**, then "responsive-ifying" — Angola users are mobile-first; desktop is the secondary case.

---

## Output to user

After generation, post:
- Path to `prototype/{name}/`
- How to run (`cd ... && npm install && npm run dev`)
- Section count generated (homepage + sub-pages)
- Color scheme proposed
- **Patterns dropped from references** (list from `manifest.discardedFromReferences`) — this proves the trim happened
- Animations included
- Suggested next: `/port-prototype prototype/{name} {suggested-template-id} {industry} {siteMode}`

Then **stop**. Do not auto-port; the user reviews the prototype visually first by running `npm run dev`.
