---
name: review
description: Perform thorough code review with SOLID principles and clean code enforcement
parameters:
  - name: target
    description: File or folder path to review
    required: false
    default: "."
---

# Code Review

Perform a thorough and practical code review on ${target}, balancing code quality with pragmatic development needs.

## Review Process

1. **SCAN** the specified files for violations
2. **PRIORITIZE** security and maintainability issues
3. **PROVIDE ACTIONABLE** feedback with specific fixes
4. **BE FAIR** - distinguish blockers from suggestions

## Critical Violations (Blockers - Must Fix)
- Hardcoded credentials, API keys, or secrets
- SQL injection vulnerabilities
- Security issues (XSS, command injection, etc.)
- Direct DOM manipulation in React (use refs if needed)
- Functions longer than 80 lines
- Files longer than 1000 lines
- Cyclomatic complexity > 15
- Missing error handling for external calls (API, DB, file I/O)
- Duplicate code blocks (>20 lines of identical code)

## High Priority Issues (Should Fix)
- `any` type in TypeScript (prefer `unknown` or proper types)
- Functions longer than 50 lines
- Files longer than 600 lines
- More than 6 function parameters (use object parameter)
- Classes with more than 20 methods
- Nested callbacks > 3 levels (callback hell)
- Missing TypeScript types on public APIs
- Direct state mutations in React
- Missing loading/error states for async operations
- Deep nesting > 4 levels

## Medium Issues (Consider Fixing)
- Functions between 30-50 lines
- Files between 400-600 lines
- Magic numbers without constants
- Console.log/print statements (use logger)
- Commented out code blocks
- Missing interface definitions for complex objects
- Inconsistent naming conventions
- No input validation on user data

## Low Priority (Nice to Have)
- Functions between 20-30 lines
- Missing JSDoc/docstrings on complex functions
- Inline styles in React (prefer Tailwind classes)
- Could extract reusable component/utility

## Output Format

Provide a structured review:

```
🔍 CODE REVIEW REPORT
=============================

📁 File: [filename]
📊 Lines: [count]
📈 Status: ❌ BLOCKED / ⚠️ NEEDS WORK / ✅ APPROVED

🔴 CRITICAL (Blockers):
- [Line X] Issue description
  Fix: Specific solution

🟠 HIGH PRIORITY:
- [Line X] Issue description
  Fix: Specific solution

🟡 MEDIUM:
- [Line X] Issue description
  Suggestion: Improvement idea

🟢 POSITIVE NOTES:
- Good patterns observed
- Well-structured code sections

📋 VERDICT: [BLOCKED/NEEDS WORK/APPROVED]
```

## Guidelines

- Focus on **real problems**, not style nitpicks
- Acknowledge **good code** - highlight positive patterns
- Provide **specific line numbers** and **concrete fixes**
- Consider **context** - is this a prototype, MVP, or production code?
- Large files aren't automatically bad if well-organized with clear sections
- Align with CLAUDE.md project standards when applicable