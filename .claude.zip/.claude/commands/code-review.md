# Code Review

Perform a comprehensive code review.

## Instructions

1. If `$ARGUMENTS` specifies a file or directory, review that scope
2. If empty, review recent changes (git diff)

## Review Checklist

### SOLID Principles
- [ ] Single Responsibility: Does each class have one reason to change?
- [ ] Open/Closed: Can behavior be extended without modification?
- [ ] Liskov Substitution: Are subtypes properly substitutable?
- [ ] Interface Segregation: Are interfaces focused and minimal?
- [ ] Dependency Inversion: Do classes depend on abstractions?

### ACID Compliance
- [ ] Are transactions properly scoped with @Transactional?
- [ ] Is isolation level appropriate for concurrent access?
- [ ] Are related operations atomic?

### Security
- [ ] Input validation present?
- [ ] SQL injection prevention (parameterized queries)?
- [ ] XSS prevention (output encoding)?
- [ ] Authentication/authorization checks?

### Code Quality
- [ ] Error handling appropriate?
- [ ] Logging sufficient but not excessive?
- [ ] No hardcoded secrets or credentials?
- [ ] Portuguese language for user-facing content?

### Design Patterns
- [ ] Proper use of Repository pattern?
- [ ] Service layer encapsulates business logic?
- [ ] DTOs separate API from domain?

Provide detailed feedback with specific line references and suggestions.
