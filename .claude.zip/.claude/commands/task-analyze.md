# Analyze Task

Analyze the specified task from the kambam backlog.

## Instructions

1. Read the task file from `kambam/backlog/$ARGUMENTS.md` or search for it if the full name isn't provided
2. Analyze the task requirements, acceptance criteria, and dependencies
3. Check if dependencies are completed (look in `kambam/done/`)
4. Identify which files need to be created or modified
5. List the technical approach following SOLID principles
6. Estimate complexity and potential blockers
7. Provide a summary with:
   - Task overview
   - Dependencies status
   - Files to create/modify
   - Technical approach
   - Potential risks or blockers
