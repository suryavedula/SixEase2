# View Logs

View container logs.

## Instructions

1. If `$ARGUMENTS` is empty, show logs for all containers: `docker-compose logs --tail=100`
2. If `$ARGUMENTS` specifies a service (backend, frontend, db, redis), show logs for that service
3. Use `-f` flag to follow logs in real-time if user requests it
