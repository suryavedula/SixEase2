# Stop Containers

Stop the development environment.

## Instructions

1. Run `docker-compose down`
2. Confirm all containers have stopped
3. Optionally remove volumes if `$ARGUMENTS` contains "clean" or "volumes"
