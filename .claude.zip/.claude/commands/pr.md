# Create Pull Request

Create a pull request with proper description.

## Instructions

1. Check current branch and changes: `git status`, `git log origin/main..HEAD`
2. Push branch if not pushed: `git push -u origin <branch>`
3. Create PR using `gh pr create`

## PR Template

```markdown
## Summary
Brief description of changes

## Task Reference
TASK-XXX: Task title

## Changes
- Change 1
- Change 2

## Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed

## Checklist
- [ ] SOLID principles followed
- [ ] ACID compliance verified
- [ ] Security review done
- [ ] Portuguese language for UI text
```

## Steps

1. Ensure all tests pass
2. Run code review command first
3. Create PR with comprehensive description
4. Link to related task in kambam
