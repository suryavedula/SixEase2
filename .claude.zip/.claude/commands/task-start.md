# Start Task

Start working on a task from the kambam backlog.

## Instructions

1. Find the task file matching `$ARGUMENTS` in `kambam/backlog/`
2. Move the task file to `kambam/in-progress/`
3. Read and analyze the task requirements
4. Verify all dependencies are in `kambam/done/`
5. If dependencies are missing, warn and ask if user wants to proceed
6. Create a todo list breaking down the implementation steps
7. Begin implementation following:
   - SOLID principles
   - Design patterns from CLAUDE.md
   - ACID compliance for database operations
8. All user-facing text must be in Portuguese
