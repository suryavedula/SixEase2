# Start Containers

Start the development environment using Docker Compose.

## Instructions

1. Run `docker-compose up -d --build`
2. Wait for containers to be healthy
3. Show container status with `docker-compose ps`
4. Display access URLs:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8080
   - PostgreSQL: localhost:5432
   - Redis: localhost:6379
5. Show recent logs if any container failed to start
