# Create Entity

Create a new JPA entity with repository, service, DTO, and controller.

## Arguments

`$ARGUMENTS` should be the entity name in PascalCase (e.g., "Product", "OrderItem")

## Instructions

1. Create the JPA entity in `backend/src/main/java/ao/kitandasmart/entity/`
   - Use Lombok annotations (@Data, @Entity, @Builder, etc.)
   - Include audit fields (createdAt, updatedAt)
   - Use UUID for primary key
   - Add proper JPA annotations

2. Create the repository interface in `backend/src/main/java/ao/kitandasmart/repository/`
   - Extend JpaRepository
   - Add common query methods

3. Create DTOs in `backend/src/main/java/ao/kitandasmart/dto/`
   - CreateXxxRequest
   - UpdateXxxRequest
   - XxxResponse

4. Create service interface and implementation in `backend/src/main/java/ao/kitandasmart/service/`
   - Follow SOLID principles
   - Use @Transactional where needed

5. Create REST controller in `backend/src/main/java/ao/kitandasmart/controller/`
   - Standard CRUD endpoints
   - Input validation
   - Proper HTTP status codes

6. Create Liquibase migration in `backend/src/main/resources/db/changelog/`

7. Follow naming conventions and design patterns from CLAUDE.md
