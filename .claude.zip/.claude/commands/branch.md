# Create Branch

Create a new feature branch for a task.

## Instructions

1. `$ARGUMENTS` should be the task ID (e.g., "TASK-010")
2. Fetch latest: `git fetch origin`
3. Create branch from main: `git checkout -b feature/$ARGUMENTS origin/main`

## Branch Naming Convention

- feature/TASK-XXX - New features
- fix/TASK-XXX - Bug fixes
- refactor/TASK-XXX - Refactoring
- chore/TASK-XXX - Maintenance tasks

## Steps

1. Parse task ID from arguments
2. Verify task exists in kambam
3. Create and checkout new branch
4. Confirm branch creation
