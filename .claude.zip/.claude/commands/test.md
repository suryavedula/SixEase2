# Run Tests

Run tests for the project.

## Instructions

1. If `$ARGUMENTS` is empty, run all tests:
   - Backend: `docker-compose exec backend ./mvnw test`
   - Frontend: `docker-compose exec frontend npm test`

2. If `$ARGUMENTS` specifies "backend" or "api":
   - Run `docker-compose exec backend ./mvnw test`

3. If `$ARGUMENTS` specifies "frontend" or "ui":
   - Run `docker-compose exec frontend npm test`

4. If `$ARGUMENTS` specifies a class name:
   - Run `docker-compose exec backend ./mvnw test -Dtest=$ARGUMENTS`

5. Show test results summary and any failures
