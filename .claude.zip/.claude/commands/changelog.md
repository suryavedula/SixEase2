# Update Changelog

Update the CHANGELOG.md file with recent changes.

## Instructions

1. If CHANGELOG.md doesn't exist, create it with Keep a Changelog format
2. Get recent commits since last tag or release
3. Categorize changes:
   - Added: New features
   - Changed: Changes to existing features
   - Fixed: Bug fixes
   - Removed: Removed features
   - Security: Security fixes

## Format

```markdown
# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added
- Feature description (TASK-XXX)

### Changed
- Change description

### Fixed
- Fix description
```

## Steps

1. Read existing CHANGELOG.md if present
2. Get commits since last version entry
3. Categorize and add new entries under [Unreleased]
4. Include task references where applicable
