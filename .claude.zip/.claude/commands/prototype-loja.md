---
name: prototype-loja
description: Generate a KitandaSmart-portable HTML prototype for an Online Store (siteMode LOJA) from one or more reference images. The prototype is locked to `frontend/lib/templates/blueprints/loja.md`. Every section visible in the images is created as a CMS-dynamic block (vendor enables/disables/edits via the visual editor); required core slots missing from the image are inferred. Sections are NEVER omitted — they're added to the CMS-dynamic library so vendors can opt in. Only platform locks (URL paths, checkout flow, payment-proof UX, PT/AOA only) are non-negotiable. Output is a mobile-first HTML + manifest.json that `/port-prototype` ingests cleanly.
parameters:
  - name: name
    description: Kebab-case prototype folder name (e.g., `mercado-bairro`, `boutique-luanda`). Becomes `prototype/{name}/` at the repo root.
    required: true
  - name: images
    description: One or more image paths (PNG/JPG). The user attaches reference screenshots, Figma exports, or competitor screenshots. Read every image with the multimodal Read tool.
    required: true
  - name: industry
    description: One of the LOJA-mode industries — `RETAIL`, `FASHION`, `BEAUTY`, `PHARMACY`, `HARDWARE`. Drives copy tone and category labels but does NOT change the section roster (the LOJA blueprint applies identically across these industries).
    required: true
  - name: style
    description: Visual style hint — `classic`, `modern`, `bold`, `premium`. Defaults to `modern`.
    required: false
  - name: notes
    description: Freeform context — brand voice, color preferences, copy direction, anything not visible in the images.
    required: false
---

# Create LOJA Prototype from Images (blueprint-locked)

This skill produces an HTML prototype for a KitandaSmart online store template, using attached images as the visual reference. The prototype is **structurally locked** to the LOJA blueprint at `frontend/lib/templates/blueprints/loja.md` — design varies, the contract does not.

## Why this skill exists separately from `/create-prototype`

`/create-prototype` is generic. This one is blueprint-aware:

- Reference images often **omit** the *required core* every LOJA template must have (cart icon in header, hero, featured-products, footer, mobile bottom nav, WhatsApp floating button). This skill **infers** any missing core slot with sensible Angola defaults.
- Reference images often **include extra sections** beyond the core (blog teaser, brand strip, video, lookbook, newsletter, instagram feed, locations map). This skill **does NOT discard them** — every image section becomes a **CMS-dynamic block** in the template, registered in the `TemplateConfig.contentSlots` and exposed in the visual editor so the vendor can enable/disable/edit/reorder it.
- The visual editor downstream depends on **CMS slot-key parity**. This skill names every slot key consistently with §8 of `loja.md` for core slots, and adds new slot keys (under a clear namespace like `block.{slot}.title`) for library blocks.

The principle: **the image dictates which sections exist; the blueprint dictates which are required; the CMS dictates which are visible per store.**

---

## Process

### Step 0 — Load the blueprint

Before doing anything else, read `frontend/lib/templates/blueprints/loja.md` end-to-end. The blueprint is the spec; the images are the reference. When they conflict, the blueprint wins.

### Step 1 — Audit every image

For each image path in `images`:

1. Read it with the multimodal Read tool.
2. Inventory:
   - Color palette (extract 5–7 dominant colors with hex codes)
   - Typography (heading vs. body, sans vs. serif, weight, scale)
   - Section types visible (label each one — "hero", "category grid", "product carousel", "testimonial slider", "blog teaser", etc.)
   - Layout patterns (full-bleed, edge-to-edge, contained, asymmetric)
   - Decorative elements (gradients, patterns, noise, overlays)

Compose a single combined inventory across all images.

### Step 2 — Map image sections → blueprint slots (core + CMS-dynamic library)

The LOJA blueprint defines two tiers (see `loja.md` §2):

- **Required core** (must be in every template, vendor cannot disable): `header` · `hero` · `featured-products` · `footer`
- **Platform-mandatory** (inherited from platform): `whatsapp-floating` · `mobile-bottom-nav`
- **CMS-dynamic library** (any number, vendor enables/disables/edits): `categories` · `promo-strip` · `social-proof` · `brand-strip` · `new-arrivals` · `bestsellers` · `lookbook` · `video-showcase` · `instagram-feed` · `blog-teaser` · `newsletter` · `locations` · `faq` · `contact-cta` · plus any new pattern the prototype introduces

For each image section:

| Image section type | Decision |
|---|---|
| Header / nav bar | → `header` slot (REQUIRED CORE), pick the closest variant |
| Big banner / hero image | → `hero` slot (REQUIRED CORE) |
| Product grid / carousel / masonry | → `featured-products` slot (REQUIRED CORE) |
| Footer | → `footer` slot (REQUIRED CORE) |
| Category tiles / pills / scroller | → `categories` (CMS-dynamic block) |
| Trust strip (delivery / payment / returns icons) | → `promo-strip` (CMS-dynamic block) |
| Testimonials | → `social-proof` (CMS-dynamic block) |
| "As seen in" / partner logos | → `brand-strip` (CMS-dynamic block) |
| Editorial photography w/ products | → `lookbook` (CMS-dynamic block) |
| Hero / brand video | → `video-showcase` (CMS-dynamic block) |
| Instagram tiles | → `instagram-feed` (CMS-dynamic block) |
| Latest articles / blog teaser | → `blog-teaser` (CMS-dynamic block; only if a blog page exists in the template) |
| Newsletter signup section | → `newsletter` (CMS-dynamic block) |
| Map / store locations | → `locations` (CMS-dynamic block) |
| FAQ accordion | → `faq` (CMS-dynamic block) |
| Mid-page contact CTA | → `contact-cta` (CMS-dynamic block) |
| Anything else not listed | → invent a new CMS-dynamic block name (kebab-case), build the component, register the slot keys |
| **Multi-language / currency switcher** | **HARD-DISCARD** — Angola is PT-only, AOA-only (platform lock) |
| **Course catalogue / class schedule** | **HARD-DISCARD** — wrong site mode (EDUCACAO) |
| **Service-booking portfolio** | **HARD-DISCARD** — wrong site mode (SERVICOS) |
| **Platform pricing / plans table** | **HARD-DISCARD** — that's the KitandaSmart platform page, not a store |

**Default rule:** prefer creating a CMS-dynamic block over discarding. The only sections that get hard-discarded are those that violate platform locks (PT/AOA-only) or belong to a different `siteMode`. Everything else becomes vendor-controllable content.

### Step 3 — Infer missing required-core slots

After mapping, check the required core (§2a). If any of these are missing from the images, infer them with sensible defaults:

- `header` → minimal sticky header with logo · cart · account icons
- `hero` → split layout with title + subtitle + primary CTA + supporting image
- `featured-products` → 6 product cards with placeholder names + AOA prices (Kz 4.500 – Kz 28.000 range; Angola-realistic)
- `footer` → contact + hours + WhatsApp + payment badges (Multicaixa, Transferencia)

Required CMS-dynamic blocks should also be inferred when **strongly expected** for the industry but absent from the image:

- `categories` → 4–6 category pills (RETAIL: "Novidades, Promocoes, Mais Vendidos, Marcas"; FASHION: "Mulher, Homem, Acessorios, Sale"; PHARMACY: "Medicamentos, Bebe, Cuidados, Beleza"; HARDWARE: "Ferramentas, Construcao, Electrica, Jardim"; BEAUTY: "Skincare, Make-up, Cabelo, Perfumes")
- `promo-strip` → 4 trust icons ("Entrega em Luanda", "Multicaixa Express", "Trocas em 7 dias", "Suporte WhatsApp")
- `social-proof` → testimonial trio with Angolan first names (Maria, Joao, Ines, Carlos, Ana)

Mark every inferred slot in `manifest.json` with `"sourcedFrom": "inferred"` so reviewers know it isn't from the image. CMS-dynamic blocks visible in the image keep `"sourcedFrom": "image-N"`.

### Step 4 — Generate the prototype

Output goes to `prototype/{name}/`:

```
prototype/{name}/
├── index.html         ← homepage with all 7 LOJA slots
├── produto.html       ← product detail (LOJA blueprint §3)
├── styles.css         ← CSS variables + section styles
└── manifest.json      ← machine-readable spec for /port-prototype
```

#### `index.html` requirements

- Mobile-first viewport, no build step, Tailwind via CDN OR vanilla CSS — pick one
- Each `<section>` carries:
  - `data-section-type="{slot}"` — one of the 7 LOJA roster names
  - `data-content-slot="{key}"` for every editable field — keys MUST come from §8 of `loja.md` (`hero.title`, `hero.subtitle`, `hero.cta.text`, `featured.title`, `about.short`, `contact.address`, etc.)
  - `data-section-anchor="{kebab-id}"` for nav anchoring
- Floating WhatsApp button (bottom-right, always visible)
- Mobile bottom nav fixed at viewport bottom (Home · Catálogo · Carrinho · Conta)
- 17-token CSS variables matching the KitandaSmart `ColorScheme` shape (see existing prototypes for reference)

#### `produto.html` requirements

LOJA blueprint §3 — must contain: gallery (multi-image), title + price + sale price + stock, variant selector (size/color), quantity stepper, add-to-cart, description, specifications, shipping info, related-products (≥4). Stub data only; this is a structural prototype.

#### `manifest.json` schema

```json
{
  "name": "{name}",
  "siteMode": "LOJA",
  "industry": "{industry}",
  "style": "{style}",
  "blueprint": "loja.md",
  "blueprintCompliance": {
    "requiredCore": {
      "header":            { "present": true, "variant": "minimal-sticky", "sourcedFrom": "image-1" },
      "hero":              { "present": true, "variant": "split",          "sourcedFrom": "image-1" },
      "featured-products": { "present": true, "variant": "grid-3",         "sourcedFrom": "image-2" },
      "footer":            { "present": true, "variant": "full",           "sourcedFrom": "image-1" }
    },
    "platformMandatory": {
      "whatsapp-floating":  { "present": true },
      "mobile-bottom-nav":  { "present": true }
    },
    "cmsDynamicBlocks": [
      { "slot": "categories",     "variant": "pills",        "sourcedFrom": "image-1", "defaultEnabled": true,  "slotKeys": ["categories.title"] },
      { "slot": "promo-strip",    "variant": "icon-row",     "sourcedFrom": "inferred", "defaultEnabled": true,  "slotKeys": ["promo.item1.label", "promo.item1.icon", "promo.item2.label", "..."] },
      { "slot": "social-proof",   "variant": "testimonials", "sourcedFrom": "image-3", "defaultEnabled": true,  "slotKeys": ["social-proof.title", "social-proof.item1.quote", "social-proof.item1.author", "..."] },
      { "slot": "lookbook",       "variant": "editorial-2col", "sourcedFrom": "image-2", "defaultEnabled": true,  "slotKeys": ["lookbook.title", "lookbook.image1", "lookbook.image2"] },
      { "slot": "newsletter",     "variant": "inline",       "sourcedFrom": "image-4", "defaultEnabled": false, "slotKeys": ["newsletter.title", "newsletter.subtitle", "newsletter.cta"] }
    ],
    "hardDiscarded": [
      { "imageSection": "language-switcher", "reason": "platform lock: PT-only" }
    ]
  },
  "colors": { "primary": "#XXXXXX", "secondary": "#XXXXXX", "...": "..." },
  "typography": { "heading": "Font Name", "body": "Font Name" },
  "contentSlots": [
    "hero.title", "hero.subtitle", "hero.image", "hero.cta.text", "hero.cta.link",
    "featured.title",
    "about.short", "about.image",
    "contact.address", "contact.phone", "contact.whatsapp", "contact.email", "contact.hours",
    "footer.text", "footer.legal",
    "seo.home.title", "seo.home.description"
  ],
  "pages": ["index.html", "produto.html"]
}
```

`cmsDynamicBlocks[].slotKeys` is the list of CMS field keys that the visual editor will expose for that block. Use the `block.{slot}.{field}` namespace (or the slot's natural name when one is established, e.g. `social-proof.item1.quote`) and keep it consistent across templates so the editor renders the same form for the same block type.

### Step 5 — Self-check before finishing

Before reporting success, verify:

- [ ] All 4 required-core slots (`header`, `hero`, `featured-products`, `footer`) have `<section data-section-type="...">` blocks in `index.html`.
- [ ] Floating WhatsApp button + mobile bottom nav present.
- [ ] Every section visible in the images is represented in the prototype — either as required-core or as a CMS-dynamic block. Nothing was silently dropped (only the `hardDiscarded` list in the manifest may be missing).
- [ ] Every required CMS slot key from §8 of `loja.md` appears as a `data-content-slot` somewhere.
- [ ] Every CMS-dynamic block declares its `slotKeys` in `manifest.json` and uses them via `data-content-slot` in the HTML.
- [ ] Every CMS-dynamic block has `defaultEnabled` set (true = visible out of the box; false = vendor opts in).
- [ ] `produto.html` contains the 9 product-detail parts from §3.
- [ ] `manifest.json` declares `"siteMode": "LOJA"` and `"blueprint": "loja.md"`.
- [ ] Mobile-first: looks correct at 375px width before adding desktop styles.

If any check fails, fix and re-verify. Do not announce completion with a known violation.

---

## Output to the user

After producing the files, report:

1. The folder path: `prototype/{name}/`
2. A one-line summary of the visual direction (palette + typography + dominant variant)
3. Which slots came from images vs. inferred (count, not full list)
4. Which image sections were discarded and why
5. Suggested next step: `/port-prototype {name}` once the prototype is reviewed

Keep the report under 200 words.

---

## Anti-patterns (do not do)

- **Do not** silently drop sections from the image. If it's not a hard-discard (platform lock or wrong site mode), it MUST become a CMS-dynamic block.
- **Do not** rename core slot keys (e.g., `hero.headline` instead of `hero.title`). The keys in §8 of `loja.md` are fixed across every LOJA template.
- **Do not** hardcode copy or images inside section components. Every editable field MUST be wired to a CMS slot key via `data-content-slot` so the visual editor can drive it.
- **Do not** swap "Comprar" for "Shop Now" or other English copy. Portuguese (Angola) only.
- **Do not** skip mobile bottom nav or floating WhatsApp because the image doesn't show them. They're platform-mandatory.
- **Do not** mark a CMS-dynamic block as "always on" — every block beyond the required core needs a `defaultEnabled` toggle so vendors can opt out.
- **Do not** auto-run `/port-prototype` after this skill — leave the review checkpoint to the user.
