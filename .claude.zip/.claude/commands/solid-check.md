# SOLID Compliance Check

Analyze code for SOLID principle compliance.

## Instructions

1. If `$ARGUMENTS` specifies a file or class, analyze that
2. If empty, analyze recent changes or the entire service layer

## Analysis

### Single Responsibility Principle
- Check each class has only one reason to change
- Identify classes that do too many things
- Suggest splits if needed

### Open/Closed Principle
- Check for switch statements that might need strategy pattern
- Identify places where adding features requires modifying existing code
- Suggest abstraction points

### Liskov Substitution Principle
- Check inheritance hierarchies
- Verify subclasses don't break base class contracts
- Identify improper inheritance relationships

### Interface Segregation Principle
- Check for "fat" interfaces
- Identify unused interface methods in implementations
- Suggest interface splits

### Dependency Inversion Principle
- Check for direct instantiation of dependencies
- Verify constructor injection is used
- Identify concrete class dependencies that should be interfaces

## Output

Provide:
1. Compliance score (percentage)
2. Violations found with severity
3. Specific recommendations with code examples
4. Priority order for fixes
