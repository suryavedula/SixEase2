# Database Migration

Run or create database migrations.

## Instructions

1. If `$ARGUMENTS` is empty or "run":
   - Run pending migrations: `docker-compose exec backend ./mvnw liquibase:update`

2. If `$ARGUMENTS` is "status":
   - Show migration status: `docker-compose exec backend ./mvnw liquibase:status`

3. If `$ARGUMENTS` is "rollback":
   - Rollback last migration: `docker-compose exec backend ./mvnw liquibase:rollback -Dliquibase.rollbackCount=1`

4. If `$ARGUMENTS` starts with "create":
   - Create a new migration file in `backend/src/main/resources/db/changelog/`
   - Use timestamp naming: `YYYYMMDDHHMMSS_description.xml`
   - Include the migration in the master changelog
